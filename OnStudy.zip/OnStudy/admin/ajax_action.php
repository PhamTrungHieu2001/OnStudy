<?php

include('Examination.php');

require ('../vendor/autoload.php');

define ('SITE_ROOT', realpath(dirname(__FILE__)));

$con = new mysqli("localhost","root","","onstudy");
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
use PhpOffice\PhpSpreadsheet\IOFactory;
use PhpOffice\PhpSpreadsheet\Worksheet\MemoryDrawing;

$exam = new Examination;

$current_datetime = date("Y-m-d") . ' ' . date("H:i:s", STRTOTIME(date('h:i:sa')));

if(isset($_POST['page']))
{
	if($_POST['page'] == 'register')
	{
		if($_POST['action'] == 'check_email')
		{
			$exam->query = "
			SELECT * FROM admins 
			WHERE admin_email_address = '".trim($_POST["email"])."'
			";

			$total_row = $exam->total_row();

			if($total_row == 0)
			{
				$output = array(
					'success'	=>	true
				);

				echo json_encode($output);
			}
		}

		// register input is sent
		if($_POST['action'] == 'register')
		{
			$receiver_email = $_POST['admin_email_address'];

			$exam->data = array(
				':admin_email_address'		=>	$receiver_email,
				':admin_password'			=>	password_hash($_POST['admin_password'], PASSWORD_DEFAULT),
				':created_time'			=>	$current_datetime
			);

			$exam->query = "
			INSERT INTO admins 
			(admin_email_address, admin_password, created_time) 
			VALUES 
			(:admin_email_address, :admin_password, :created_time)
			";

			$exam->execute_query();

			$output = array(
				'success'	=>	true
			);

			echo json_encode($output);
		}
	}

	if($_POST['page'] == 'login')
	{
		if($_POST['action'] == 'login')
		{
			$exam->data = array(
				':admin_email_address'	=>	$_POST['admin_email_address']
			);

			$exam->query = "
			SELECT * FROM admins 
			WHERE admin_email_address = :admin_email_address
			";

			$total_row = $exam->total_row();

			if($total_row > 0)
			{
				$result = $exam->query_result();

				foreach($result as $row)
				{
					if(password_verify($_POST['admin_password'], $row['admin_password']))
					{
						$_SESSION['admin_id'] = $row['admin_id'];
						$output = array(
							'success'	=>	true
						);
					}
					else
					{
						$output = array(
							'error'	=>	'Wrong Password'
						);
					}
				}
			}
			else
			{
				$output = array(
					'error'		=>	'Wrong Email Address'
				);
			}
			echo json_encode($output);
		}
	}

	if($_POST['page'] == 'exam')
	{
		// display all exams
		if($_POST['action'] == 'fetch')
		{
			$output = array();
			$sort_query = '';

			$admin_id = $_SESSION["admin_id"];

			$exam->query = "
			SELECT * FROM exams 
			WHERE admin_id = '$admin_id' 
			AND (
			";

			// Search exam by title/duration/total questions
			if(isset($_POST['search']['value']))
			{
				$search = $exam->clean_search_results($_POST["search"]["value"]);
			 	$exam->query .= 'exams.exam_title LIKE "%'.$search.'%" ';
			}

			$exam->query .= ')';

			// Order of exams
			if(isset($_POST['order']))
			{
				if ($_POST['order']['0']['column'] == '2') {
					$sort_query = ' ORDER BY exam_duration '.$_POST['order']['0']['dir'].' ';
				}
				else if ($_POST['order']['0']['column'] == '3') {
					$sort_query = ' ORDER BY total_question '.$_POST['order']['0']['dir'].' ';
				}
				else if ($_POST['order']['0']['column'] == '4') {
					$sort_query = ' ORDER BY exam_created_time '.$_POST['order']['0']['dir'].' ';
				}
				$exam->query .= $sort_query;
			}
			else
			{
				$exam->query .= 'ORDER BY exam_id DESC ';
			}

			$extra_query = '';

			if($_POST['length'] != -1)
			{
				$extra_query .= 'LIMIT ' . $_POST['start'] . ', ' . $_POST['length'];
			}

			$filtered_rows = $exam->total_row();

			$exam->query .= $extra_query;

			$result = $exam->query_result();

			$exam->query = "SELECT * FROM exams 
			WHERE admin_id = '$admin_id'
			";

			$total_rows = $exam->total_row();

			$data = array();
			// for each question
			foreach($result as $row)
			{
				$sub_array = array();
				$exam_image_url = $row['exam_image'];
				if ($exam_image_url == '') {
					$exam_image_url = "default.jpg";
				}
 				$exam_image = '<img src="./upload/'.$exam_image_url.'" class="img-fluid">';
				$sub_array[] = $exam_image;
				$sub_array[] = html_entity_decode($row['exam_title']);
				$sub_array[] = $row['exam_duration'] . ' Minutes';
				$sub_array[] = $row['total_question'] . ' Questions';
				$exam_date = date("d-m-Y", strtotime($row['exam_created_time']));
				$sub_array[] = $exam_date;

				$status = '';
				$edit_button = '';
				$delete_button = '';
				$question_button = '';
				$result_button = '';

				$edit_button = '
				<button type="button" name="edit" class="btn btn-primary btn-sm edit" id="'.$row['exam_id'].'">Edit</button>
				';
				$delete_button = '<button type="button" name="delete" class="btn btn-danger btn-sm delete" id="'.$row['exam_id'].'">Delete</button>';
				$result_button = '<a href="exam_result.php?code='.$row["online_exam_code"].'" class="btn btn-dark btn-sm">History</a>';

				$question_button = '
				<button type="button" name="add_question" class="btn btn-info btn-sm add_question" id="'.$row['exam_id'].'">Add Question</button>
				';

				$question_button = '
				<a href="question.php?code='.$row['online_exam_code'].'" class="btn btn-warning btn-sm">View Questions</a>	
				';

				$sub_array[] = $question_button;

				$sub_array[] = $result_button;

				$sub_array[] = $edit_button . ' ' . $delete_button;

				$data[] = $sub_array;
			}
			$dir = sys_get_temp_dir(); // C:\\WINDOWS\\TEMP

			$output = array(
				"draw"				=>	intval($_POST["draw"]),
				"adminid"			=>  $admin_id,
				"directory"			=> 	$dir,
				"recordsTotal"		=>	$total_rows,
				"recordsFiltered"	=>	$filtered_rows,
				"data"				=>	$data
			);
			echo json_encode($output);
		}

		if($_POST['action'] == 'Add')
		{
			$online_exam_code = uniqid();

			// exam image
			$imageName = $_FILES["exam_image"]["name"];
			$newname = "";
			if ($imageName != "") {
				$extension = pathinfo($imageName, PATHINFO_EXTENSION);
				$tempname = $_FILES["exam_image"]["tmp_name"];	
				$newname = $online_exam_code . '.' . $extension;
				$folder = SITE_ROOT . "/upload/" . $newname;
				// $root = SITE_ROOT;	
				
				move_uploaded_file($tempname, $folder);	
			}
			$exam->data = array(
				':admin_id'				=>	$_SESSION['admin_id'],
				':exam_title'			=>	$exam->clean_data($_POST['exam_title']),
				':exam_image'			=> 	$newname,
				':exam_duration'		=>	$_POST['exam_duration'],
				':exam_created_time'	=>	$current_datetime,
				':online_exam_code'		=>	$online_exam_code
			);

			// -- insert exam --
			$exam->query = "
			INSERT INTO exams 
			(admin_id, exam_title, exam_image, exam_duration, exam_created_time, online_exam_code) 
			VALUES (:admin_id, :exam_title, :exam_image, :exam_duration, :exam_created_time, :online_exam_code)
			";
			$exam->execute_query();

			// select with exam code
			$online_exam_code = $exam->data[':online_exam_code'];
			$exam->query = "SELECT * FROM exams WHERE online_exam_code = '$online_exam_code'
			";
			$result = mysqli_query($con, $exam->query);
			$total_row = mysqli_num_rows($result);
			$total_question = 0;

			if($total_row > 0) // check if exam exists in database
			{
				foreach ($result as $row) { 
					$exam_id = $row['exam_id'];
					// -- insert question --
					$targetPath = $_FILES['question_list']['tmp_name'];
					$spreadsheet = \PhpOffice\PhpSpreadsheet\IOFactory::load($targetPath);
					$question = $spreadsheet->getActiveSheet()->toArray();
					// count total number of questions
					$total_question = sizeof($question) - 1; // minus the first row
					$exam->data = array (
						':total_question' => $total_question
					);
					$exam->query = " UPDATE exams 
					SET total_question = :total_question WHERE exam_id = $exam_id
					";
					$exam->execute_query();
					$first_row = '';
					$extension = '';
					$imageContents = '';

					// read images in excel file
					// return an ArrayObject of all the image objects in the active worksheet
					foreach ($spreadsheet->getActiveSheet()->getDrawingCollection() as $drawing) {
						if ($drawing instanceof MemoryDrawing) {
							ob_start();
							call_user_func(
								$drawing->getRenderingFunction(),
								$drawing->getImageResource()
							);
							$imageContents = ob_get_contents();
							ob_end_clean();
							switch ($drawing->getMimeType()) {
								case MemoryDrawing::MIMETYPE_PNG :
									$extension = 'png';
									break;
								case MemoryDrawing::MIMETYPE_GIF:
									$extension = 'gif';
									break;
								case MemoryDrawing::MIMETYPE_JPEG :
									$extension = 'jpg';
									break;
							}
						}
						else {
							if ($drawing->getPath()) {
								// Check if the source is a URL or a file path
								if ($drawing->getIsURL()) {
									$imageContents = file_get_contents($drawing->getPath());
									$filePath = tempnam(sys_get_temp_dir(), 'Drawing');
									file_put_contents($filePath , $imageContents);
									$mimeType = mime_content_type($filePath);
									$extension = File::mime2ext($mimeType);
									unlink($filePath);            
								}
								else {
									$zipReader = fopen($drawing->getPath(),'r');
									$imageContents = '';
									while (!feof($zipReader)) {
										$imageContents .= fread($zipReader,1024);
									}
									fclose($zipReader);
									$extension = $drawing->getExtension();            
								}
							}
						}	
						$cord = $drawing->getCoordinates();				
						$myFileName = 'upload/'.$exam_id.'_'.$cord.'.'.$extension;
						file_put_contents($myFileName,$imageContents);
					}

					// for each question
					foreach($question as $row) { 
						$question_order = $row[0];
						// start fetching data from the second row
						if (is_numeric($question_order)) {
							$question_id = uniqid();
							$question_title = $row[1];
							// save image to db
							$question_image = '';
							// check if the question has an image
							$question_order++; // -> row coordinate
							$imageCoordinate = "E" . $question_order; 
							// find the image name in folder -> save question_image
							if (glob("upload/".$exam_id."_".$imageCoordinate.".*")) { // if found
								foreach (glob("upload/".$exam_id."_".$imageCoordinate.".*") as $filename) {
									$question_image = $filename;
								}
							}
							$options = explode("\n", $row[2]); // split options into an array
							$count = count($options); // number of options in a question
							$right_answers = explode(",", str_replace(' ', '', strtoupper($row[3]))); // uppercase -> remove all spaces
							$right_index = 0;
							$right_answer = 0;
							// convert the right answer from alphabets -> numbers
							$alphabet = range('A', 'Z'); // A-Z: 0-25
							// if there's only 1 correct answer => $right_answer = number
							if (count($right_answers) == 1) {
								$right_index = array_search($right_answers[0], $alphabet) + 1;  // convert index of array => index of option
							}
							// number of correct answers > 1 => loop through correct answers
							else {
								// $right_index = implode("," , $right_answers);
								$right_index = ""; //  => $right_answer = string
								for ($i = 0; $i < count($right_answers); $i++) {
									$right_answer = array_search($right_answers[$i], $alphabet) + 1; 
									$right_index .= $right_answer;
									// not adding "," at the last element
									if ($i < count($right_answers) - 1) {
										$right_index .= ",";
									}
								} 
							}

							$exam->data = array(
								':exam_id' => $exam_id,
								':question_title' => $question_title,
								':question_image' => $question_image,
								':right_answer' => $right_index,
								':question_id' => $question_id
							);

							$exam->query = "
							INSERT INTO questions (question_id, exam_id, question_title, question_image, answer_option)
							VALUES (:question_id, :exam_id, :question_title, :question_image, :right_answer)
							";
							$exam->execute_query();
							
							// -- insert options --
							// remove blank options
							for ($i = 0; $i < $count; $i++) {
								if ($options[$i] == "") {
									array_splice($options, $i, 1);
									$i--;
									$count--;
								}
							}
							$count = count($options);
							// insert non-blank options
							for ($i = 0; $i < $count; $i++) {
								$option_id = uniqid();
								$exam->data = array(
									':option_id' => $option_id,
									':question_id' => $question_id,
									':option_number' => $i+1,
									':option_title' => $options[$i]
								);
								$exam->query = "
								INSERT INTO options VALUES (:option_id, :question_id, :option_number, :option_title)
								";
								$exam->execute_query();
							}
						}
					}
				}
			}	
			$output = array(
				'success'			=> 'New exam added!',
				'online_exam_code' 	=> $online_exam_code,
				'imageContents'     => $imageContents,
				'imageName' 		=> $imageName,
				'total_question' 	=> $total_question,
			);
			echo json_encode($output);		
		}

		if($_POST['action'] == 'edit_fetch')
		{
			$exam->query = "
			SELECT * FROM exams 
			WHERE exam_id = '".$_POST["exam_id"]."'
			";

			$result = $exam->query_result();

			foreach($result as $row)
			{
				$output['exam_title'] = $row['exam_title'];

				$output['exam_duration'] = $row['exam_duration'];

				$output['exam_image'] = $row['exam_image'];
			}

			echo json_encode($output);
		}

		if($_POST['action'] == 'Edit')
		{
			$newname = '';
			$online_exam_code = $exam->Get_exam_code($_POST['exam_id']);
			// delete image <=> delete checkbox is checked
			if ($_POST['delete_image'] == 'yes') {
				// delete exam image in the folder
				foreach (glob("upload/".$online_exam_code.".*") as $filename) {
					unlink($filename);
				}
			}	
			else {
				// if exam image is changed
				if ($_FILES["exam_image"]["name"] != '') {
					$extension = pathinfo($_FILES["exam_image"]["name"], PATHINFO_EXTENSION);
					$tempname = $_FILES["exam_image"]["tmp_name"];	
					$newname = $online_exam_code . '.' . $extension;
					$folder = SITE_ROOT . "/upload/" . $newname;
	
					move_uploaded_file($tempname, $folder);
				}	
				// if exam image is not changed
				else {
					$newname = $exam->Get_exam_image($_POST['exam_id']);
				}
			}
			$exam->data = array(
				':exam_title'		=>	$_POST['exam_title'],
				':exam_duration'	=>	$_POST['exam_duration'],
				':exam_image'		=>  $newname,
				':exam_id'			=>	$_POST['exam_id']
			);

			// update exam title and duration and image
			$exam->query = "UPDATE exams 
			SET exam_title = :exam_title, exam_duration = :exam_duration, exam_image = :exam_image
			WHERE exam_id = :exam_id
			";					

			$exam->execute_query($exam->data);

			$output = array(
				'success'	=>	'Exam details have been changed!',
				'exam_title' => $_POST['exam_title']
			);

			echo json_encode($output);
		}
		if($_POST['action'] == 'delete')
		{
			$online_exam_code = $exam->Get_exam_code($_POST['exam_id']);
			$exam_id = $_POST['exam_id'];
			$exam->data = array(
				':exam_id'	=>	$_POST['exam_id']
			);

			// delete image from upload folder
			$exam->query = ' SELECT * FROM exams 
			WHERE exam_id = :exam_id
			';
			$result = $exam->query_result();
			$exam_image = '';
			$image_to_delete = '';
			
			foreach ($result as $row) {
				$exam_image = $row['exam_image'];
			}

			if ($exam_image != '') {
				$image_to_delete = SITE_ROOT . "\\upload\\" . $exam_image;
				// delete the image
				unlink($image_to_delete);
			}			

			// delete data from database
			$exam->query = "DELETE FROM exams 
			WHERE exam_id = :exam_id
			";
			$exam->execute_query();
			// delete question image in the folder
			foreach (glob("upload/".$exam_id."_*") as $filename) {
				unlink($filename);
			}

			$output = array(
				'success'	=>	'Exam has been removed!',
				'image_to_delete'	=>	$image_to_delete
			);

			echo json_encode($output);
		}
	}

	if($_POST['page'] == 'question')
	{
		// view all questions
		if($_POST['action'] == 'fetch')
		{
			$output = array();
			$exam_id = '';
			if(isset($_POST['code']))
			{
				$exam_id = $exam->Get_exam_id($_POST['code']); // get exam id from exam code
			}
			$exam->query = "
			SELECT * FROM questions 
			WHERE exam_id = '".$exam_id."' 
			AND (
			";

			if(isset($_POST['search']['value']))
			{
				$search = $exam->clean_search_results($_POST["search"]["value"]);
					$exam->query .= 'question_title LIKE "%'.$search.'%" ';
			}

			$exam->query .= ')';

			// if(isset($_POST["order"]))
			// {
			// 	$exam->query .= '
			// 	ORDER BY '.$_POST['order'][0]['column'].' '.$_POST['order'][0]['dir'].' 
			// 	';
			// }
			// else
			// {
			$exam->query .= 'ORDER BY question_id ASC ';
			// }

			$extra_query = '';

			if($_POST['length'] != -1)
			{
				$extra_query .= 'LIMIT ' . $_POST['start'] . ', ' . $_POST['length'];
			}

			$filtered_rows = $exam->total_row();

			$exam->query .= $extra_query;

			$result = $exam->query_result();

			$total_rows = $exam->total_row();

			$data = array();

			$count = 0;

			// for each question
			foreach($result as $row) 
			{
				$sub_array = array();
				$count++;
				$sub_array[] = $count; // order of the question
				$sub_array[] = $row['question_title'];
				if ($row['question_image'] != '') {
					$sub_array[] = '<img src="../admin/'.$row['question_image'].'" class="img-fluid">';
				}
				else {
					$sub_array[] = ' ';
				}
				// display all options
				$question_id = $row['question_id'];
				$exam->query = "SELECT * FROM options WHERE question_id = '$question_id'";
				$result2 = $exam->query_result();
				$options = "";
				$right_answer = "";
				// 1 correct answer
				if (is_numeric($row['answer_option'])) {
					// for each option
					foreach ($result2 as $i=>$option_row) {
						$options .= $option_row['option_title'];
						$options .= "<br>";
						if ($i+1 == $row['answer_option']) {
							$right_answer = $option_row['option_title'];
						}
					}
				}
				// > 1 correct answer
				else if (is_string($row['answer_option'])) {
					$right_answers = explode(',', $row['answer_option']);
					// for each option
					foreach ($result2 as $i=>$option_row) {
						$options .= $option_row['option_title'];
						$options .= "<br>";
						$index = $i + 1;
						if (in_array($index, $right_answers)) {
							$right_answer .= $option_row['option_title'];
							$right_answer .= "<br>";
						}
					}
				}

				$sub_array[] = $options;
				$sub_array[] = $right_answer;
				$edit_button = '<button type="button" name="edit" class="btn btn-primary btn-sm edit" id="'.$row['question_id'].'">Edit</button>';
				$delete_button = '<button type="button" name="delete" class="btn btn-danger btn-sm delete" id="'.$row['question_id'].'">Delete</button>';
				$sub_array[] = $edit_button . ' ' . $delete_button;
				$data[] = $sub_array;
			}

			$output = array(
				"draw"		=>	intval($_POST["draw"]),
				"recordsTotal"	=>	$total_rows,
				"recordsFiltered"	=>	$filtered_rows,
				"data"		=>	$data
			);

			echo json_encode($output);
		}
		
		if($_POST['action'] == 'Add')
		{
			$question_id = uniqid();
			$exam_code = $_POST['exam_code'];
			$exam_id = $exam->Get_exam_id($exam_code);
			$answer_option = $_POST['answer_options']; 
			// get image file
			$newname = "";
			if (isset($_FILES["question_image"])) {
				$imageName = $_FILES["question_image"]["name"];
				$extension = pathinfo($imageName, PATHINFO_EXTENSION);
				$tempname = $_FILES["question_image"]["tmp_name"];	
				$newname = "upload/" . $exam_id . '_' . $question_id . '.' . $extension; // exam_id + question_id
				$folder = SITE_ROOT . "/" . $newname;				
				move_uploaded_file($tempname, $folder);	
			}
			
			// update total number of questions
			$exam->query = "UPDATE exams 
			SET total_question = total_question + 1 
			WHERE exam_id = '$exam_id'
			";
			$exam->execute_query();
			
			$exam->data = array(
				':question_id'  		=>  $question_id,
				':exam_id'				=>	$exam_id,
				':question_title'		=>	$exam->clean_data($_POST['question_title']),
				':question_image' 		=>	$newname
			);
			// -> insert question
			$exam->query = "
			INSERT INTO questions (question_id, exam_id, question_title, question_image)
			VALUES (:question_id, :exam_id, :question_title, :question_image)
			";
			$exam->execute_query();

			// -> insert options
			$total_option = $_POST['total_option'];
			// $blank = 0;
			// $option_number = 0;
			$answer = "";

			// loop through options
			for($count = 1; $count <= $total_option; $count++)
			{
				// $option_number = $count - $blank;
				// if ($_POST['option_title_' . $count] == '') {
				// 	$blank++;
				// 	continue;
				// }
				$option_id = uniqid();
				$exam->data = array(
					':option_id' 		=>  $option_id,
					':question_id'		=>	$question_id,
					':option_number'	=>	$count,
					':option_title'		=>	$_POST['option_title_' . $count]
				);
				$exam->query = "
				INSERT INTO options 
				VALUES (:option_id, :question_id, :option_number, :option_title)
				";
				$exam->execute_query();

				// check if count = answer option
				// split answer_option to array
				$answers = explode(",", $answer_option);
				if (in_array($count, $answers)) {
					$answer .= $count;
					// if not the last item
					if (array_search($count, $answers) < count($answers) - 1) {
						$answer .= ',';
					}
				}
			}
			$exam->data = array(
				':answer_option' => $answer
			);
			$exam->query = "UPDATE questions SET answer_option = :answer_option 
			WHERE question_id = '$question_id'
			";
			$exam->execute_query();

			$output = array(
				'success'		=>	'Question added!',
			);
			echo json_encode($output);
		}

		// click on edit button -> add info to the form
		if($_POST['action'] == 'edit_fetch')
		{
			$exam->query = "
			SELECT * FROM options 
			WHERE question_id = '".$_POST["question_id"]."'
			";

			$total_option = $exam->total_row();
			
			$exam->query = "
			SELECT * FROM questions 
			WHERE question_id = '".$_POST["question_id"]."'
			";

			$result = $exam->query_result();

			foreach($result as $row) 
			{
				$output['question_title'] = $row['question_title'];

				$output['question_image'] = $row['question_image'];

				$output['answer_option'] = explode(',', $row['answer_option']);

				$output['total_option'] = $total_option;

				for($i = 1; $i <= $total_option; $i++)
				{
					$exam->query = "
					SELECT option_title FROM options 
					WHERE question_id = '".$_POST["question_id"]."' 
					AND option_number = '".$i."'
					";

					$sub_result = $exam->query_result();

					foreach($sub_result as $sub_row)
					{
						$output["option_title_" . $i] = $sub_row["option_title"];
					}
				}
			}
			echo json_encode($output);
		}

		// save edited question & edited options & removed options
		if($_POST['action'] == 'Edit')
		{
			$exam_id = $exam->Get_exam_id($_POST['exam_code']);
			$question_id = $_POST["question_id"];
			$exam->query = "
			SELECT * FROM options 
			WHERE question_id = '$question_id'
			";
			$previous_total_option = $exam->total_row();

			$answer_option = $_POST['answer_options'];
			$answers = explode(",", $answer_option);
			$total_option = $_POST['total_option'];
			$answer = "";
		
			// if new total = previous total options
			for ($count = 1; $count <= min($previous_total_option, $total_option); $count++) {
				$exam->data = array(
					':question_id'		=>  $question_id,
					':option_number'	=>	$count,
					':option_title'		=>	$_POST['option_title_' . $count]
				);
				$exam->query = " UPDATE options 
				SET option_title = :option_title 
				WHERE question_id = :question_id 
				AND option_number = :option_number
				";
				$exam->execute_query(); 
				// save answer option
				if (in_array($count, $answers)) {
					$answer .= $count;
					// if not the last item
					if (array_search($count, $answers) < count($answers) - 1) {
						$answer .= ',';
					}
				}
			}
			// if new total < previous total options => delete
			if ($total_option < $previous_total_option) {
				$exam->data = array(
					':question_id'		=>	$question_id,
					':total_option'	=>	$total_option,
				);
				$exam->query = "DELETE FROM options 
				WHERE question_id = :question_id 
				AND option_number > :total_option
				";
				$exam->execute_query();
			}
			// if new total > previous options => insert 
			else if ($total_option > $previous_total_option) {
				for ($count = $previous_total_option + 1; $count <= $total_option; $count++) {
					$option_id = uniqid();
					$exam->data = array(
						':option_id' 		=>  $option_id,
						':question_id'		=>	$question_id,
						':option_number'	=>	$count,
						':option_title'		=>	$_POST['option_title_' . $count]
					);
					$exam->query = "
					INSERT INTO options 
					VALUES (:option_id, :question_id, :option_number, :option_title)
					";
					$exam->execute_query();	
					// save answer option
					if (in_array($count, $answers)) {
						$answer .= $count;
						// if not the last item
						if (array_search($count, $answers) < count($answers) - 1) {
							$answer .= ',';
						}
					}
				} 
			}
			// get image file
			$newname = "";
			$exam->data = array	();
			// delete image <=> delete checkbox is checked
			if ($_POST['delete_image'] == 'yes') {
				// delete question image in the folder
				$question_image_path = $exam->Get_question_image($question_id);
				foreach (glob($question_image_path."*") as $filename) {
					unlink($filename);
				}
			}	
			else {
				// if exam image is changed
				if (isset($_FILES["question_image"])) {
					$imageName = $_FILES["question_image"]["name"];
					$extension = pathinfo($imageName, PATHINFO_EXTENSION);
					$tempname = $_FILES["question_image"]["tmp_name"];	
					$newname = "upload/" . $exam_id . '_' . $question_id . '.' . $extension; // exam_id + question_id
					$folder = SITE_ROOT . "/" . $newname;				
					move_uploaded_file($tempname, $folder);	
				}
				// if exam image is not changed
				else {
					$newname = $exam->Get_question_image($question_id);
				}
			}
			
			// update question info
			$exam->data = array(
				':question_title'		=>	$_POST['question_title'],
				':question_image'		=>  $newname,
				':answer_option'		=>	$answer,
				':question_id'			=>	$question_id
			);
			$exam->query = " UPDATE questions 
			SET question_title = :question_title, question_image = :question_image, answer_option = :answer_option
			WHERE question_id = :question_id
			";
			$exam->execute_query();
			
			$output = array(
				'success'	=>	'Question edited!',
				'previous_total_option' => $previous_total_option,
				'total_new_options' => $total_option
			);

			echo json_encode($output);
		}

		if($_POST['action'] == 'delete')
		{
			$exam_code = $_POST['exam_code'];
			$exam_id = $exam->Get_exam_id($exam_code);

			// update total number of questions
			$exam->query = "UPDATE exams 
			SET total_question = total_question - 1 
			WHERE exam_id = '$exam_id'
			";
			$exam->execute_query();
			
			$exam->data = array(
				':question_id'	=>	$_POST['question_id']
			);
			// get image url from question_id
			$exam->query = "SELECT question_image FROM questions WHERE
			question_id = :question_id
			";
			$result = $exam->query_result();
			$question_image = '';
			foreach ($result as $row) {
				$question_image = $row['question_image'];
			}
			// delete question image in upload folder
			if ($question_image != '') {
				foreach (glob($question_image) as $filename) {
					unlink($filename);
				}
			}

			$exam->query = "
			DELETE FROM questions 
			WHERE question_id = :question_id
			";
			$exam->execute_query();

			$output = array(
				'success'	=>	'Question removed!'
			);

			echo json_encode($output);
		}

		// if($_POST['action'] == 'delete_all_question') 
		// {
		// 	$exam_code = $_POST['exam_code'];
		// 	$exam_id = $exam->Get_exam_id($exam_code);
			
		// 	$exam->query = "UPDATE exams 
		// 	SET total_question = 0 
		// 	WHERE exam_id = '$exam_id'
		// 	";
		// 	$exam->execute_query();

		// 	$exam->data = array(
		// 		':exam_id' => $exam_id,
		// 	);
		// 	$exam->query = "DELETE FROM questions 
		// 	WHERE exam_id = :exam_id
		// 	";
		// 	$exam->execute_query();

		// 	$output = array(
		// 		'success'	=>	'All questions have been removed!',
		// 		'exam_id'	=>	 $exam_id
		// 	);

		// 	echo json_encode($output);
		// }
	}

	if($_POST['page'] == 'user')
	{
		if($_POST['action'] == 'fetch')
		{
			$output = array();

			$exam->query = "
			SELECT * FROM users 
			WHERE ";

			if(isset($_POST["search"]["value"]))
			{
			 	$exam->query .= 'user_email_address LIKE "%'.$_POST["search"]["value"].'%" ';
			 	$exam->query .= 'OR user_name LIKE "%'.$_POST["search"]["value"].'%" ';
			}
			
			if(isset($_POST["order"]))
			{
				$exam->query .= 'ORDER BY '.$_POST['order']['0']['column'].' '.$_POST['order']['0']['dir'].' ';
			}
			else
			{
				$exam->query .= 'ORDER BY user_id DESC ';
			}

			$extra_query = '';

			if($_POST["length"] != -1)
			{
			 	$extra_query .= 'LIMIT ' . $_POST['start'] . ', ' . $_POST['length'];
			}

			$filterd_rows = $exam->total_row();

			$exam->query .= $extra_query;

			$result = $exam->query_result();

			$exam->query = "
			SELECT * FROM users";

			$total_rows = $exam->total_row();

			$data = array();

			foreach($result as $row)
			{
				$sub_array = array();
				$sub_array[] = $row["user_name"];
				$sub_array[] = $row["user_email_address"];
				$exam->query = "SELECT COUNT(DISTINCT exam_id) as exam_completed FROM history 
				WHERE user_id = ".$row['user_id']." 
				";
				$result2 = $exam->query_result();
				foreach ($result2 as $sub_row) {
					$sub_array[] = $sub_row['exam_completed'];
				}
				$data[] = $sub_array;
			}

			$output = array(
			 	"draw"    			=> 	intval($_POST["draw"]),
			 	"recordsTotal"  	=>  $total_rows,
			 	"recordsFiltered" 	=> 	$filterd_rows,
			 	"data"    			=> 	$data
			);
			echo json_encode($output);	
		}
		if($_POST['action'] == 'fetch_data')
		{
			$exam->query = "
			SELECT * FROM users 
			WHERE user_id = '".$_POST["user_id"]."'
			";
			$result = $exam->query_result();
			$output = '';
			foreach($result as $row)
			{
				$is_email_verified = '';
				if($row["user_email_verified"] == 'yes')
				{
					$is_email_verified = '<label class="badge badge-success">Email Verified</label>';
				}
				else
				{
					$is_email_verified = '<label class="badge badge-danger">Email Not Verified</label>';	
				}

				$output .= '
				<div class="row">
					<div class="col-md-12">
						<div align="center">
							<img src="../upload/'.$row["user_image"].'" class="img-thumbnail" width="200" />
						</div>
						<br />
						<table class="table table-bordered">
							<tr>
								<th>Name</th>
								<td>'.$row["user_name"].'</td>
							</tr>
							<tr>
								<th>Gender</th>
								<td>'.$row["user_gender"].'</td>
							</tr>
							<tr>
								<th>Address</th>
								<td>'.$row["user_address"].'</td>
							</tr>
							<tr>
								<th>Mobile No.</th>
								<td>'.$row["user_mobile_no"].'</td>
							</tr>
							<tr>
								<th>Email</th>
								<td>'.$row["user_email_address"].'</td>
							</tr>
							<tr>
								<th>Email Status</th>
								<td>'.$is_email_verified.'</td>
							</tr>
						</table>
					</div>
				</div>
				';
			}	
			echo $output;			
		}
	}

	if($_POST['page'] == 'exam_result')
	{
		if($_POST['action'] == 'fetch')
		{
			$output = array();

			$exam_id = $exam->Get_exam_id($_POST['code']);

			$exam->query = "SELECT * FROM history 
			WHERE exam_id = '".$exam_id."' 
			";

			// if(isset($_POST['search']['value']))
			// {
			// 	$exam->query .= '
			// 	users.user_name LIKE "%'.$_POST["search"]["value"].'%" 
			// 	';
			// }
			// $exam->query .= ') ';

			if(isset($_POST['order']))
			{
				$exam->query .= ' ORDER BY '.$_POST['order']['0']['column'].' '.$_POST['order']['0']['dir'].' ';
			}
			else
			{
				$exam->query .= ' ORDER BY user_id ASC ';
			}

			// $extra_query = '';

			if($_POST['length'] != -1)
			{
				$extra_query = ' LIMIT ' . $_POST['start'] . ', ' . $_POST['length'];
			}

			$filtered_rows = $exam->total_row();

			$exam->query .= $extra_query;

			$exam->query = "SELECT user_name, score, finished_date from users u
			INNER JOIN (SELECT * FROM history 
			WHERE exam_id = '".$exam_id."') h
			ON u.user_id = h.user_id
			";

			$result = $exam->query_result();

			$total_rows = $exam->total_row();

			$data = array();

			foreach($result as $row)
			{
				$sub_array = array();
				$sub_array[] = $row["user_name"];
				$sub_array[] = $row["score"];
				$sub_array[] = $row["finished_date"];

				$data[] = $sub_array;
			}

			$output = array(
				"draw"				=>	intval($_POST["draw"]),
				"recordsTotal"		=>	$total_rows,
				"recordsFiltered"	=>	$filtered_rows,
				"data"				=>	$data
			);

			echo json_encode($output);
		}
	}
}

?>