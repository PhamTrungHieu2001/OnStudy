<?php

class Examination
{
	var $host;
	var $username;
	var $password;
	var $database;
	var $connect;
	var $home_page;
	var $query;
	var $data;
	var $statement;
	var $filedata;

	function __construct()
	{
		$this->host = 'localhost';
		$this->username = 'root';
		$this->password = '';
		$this->database = 'onstudy';
		$this->home_page = 'http://localhost/tutorial/online_examination/';

		$this->connect = new PDO("mysql:host=$this->host; dbname=$this->database", "$this->username", "$this->password");

		session_start();
	}

	function execute_query()
	{
		// -> SQL statement template is created and sent to the database. Certain values are left unspecified (Example: INSERT INTO Table VALUES(?, ?, ?))
		// -> DB parses, compiles, and performs query optimization on the SQL statement template, and stores the result without executing it
		$this->statement = $this->connect->prepare($this->query);
		// Later, the application binds the values to the parameters, and the database executes the statement.
		$this->statement->execute($this->data);
		// => send only the parameters each time, and not the whole query.
	}

	function total_row()
	{
		$this->execute_query();
		return $this->statement->rowCount();
	}

	function query_result()
	{
		$this->execute_query();
		return $this->statement->fetchAll();
	}

	function redirect($page)
	{
		header('location:'.$page.'');
		exit;
	}

	function admin_session_private()
	{
		if(!isset($_SESSION['admin_id']))
		{
			$this->redirect('login.php');
		}
	}

	function admin_session_public()
	{
		if(isset($_SESSION['admin_id']))
		{
			$this->redirect('exam.php');
		}
	}

	function clean_data($data)
	{
	 	$data = trim($data);
	  	$data = stripslashes($data);
		$data = preg_replace('/\s\s+/', ' ',$data);
	  	$data = htmlspecialchars($data);
	  	return $data;
	}

	function Get_exam_question_limit($exam_id)
	{
		$this->query = "
		SELECT total_question FROM exams 
		WHERE exam_id = '$exam_id'
		";

		$result = $this->query_result();

		foreach($result as $row)
		{
			return $row['total_question'];
		}
	}

	function Get_exam_total_question($exam_id)
	{
		$this->query = "
		SELECT question_id FROM questions 
		WHERE exam_id = '$exam_id'
		";

		return $this->total_row();
	}

	function Get_exam_title($exam_code) {
		$this->query = "SELECT * FROM exams 
		WHERE online_exam_code = '$exam_code' ";

		$result = $this->query_result();

		foreach ($result as $row) {
			return $row['exam_title'];
		}
	}

	function Get_exam_image($exam_id) {
		$this->query = "SELECT * FROM exams 
		WHERE exam_id = '$exam_id' ";

		$result = $this->query_result();

		foreach ($result as $row) {
			return $row['exam_image'];
		}
	}

	function Get_question_image($question_id) {
		$this->query = "SELECT * FROM questions 
		WHERE question_id = '$question_id' ";

		$result = $this->query_result();

		foreach ($result as $row) {
			return $row['exam_image'];
		}
	}

	function Is_allowed_add_question($exam_id)
	{
		$exam_question_limit = $this->Get_exam_question_limit($exam_id);

		$exam_total_question = $this->Get_exam_total_question($exam_id);

		if($exam_total_question >= $exam_question_limit)
		{
			return false;
		}
		return true;
	}

	function execute_question_with_last_id()
	{
		$this->statement = $this->connect->prepare($this->query);

		$this->statement->execute($this->data);

		return $this->connect->lastInsertId();
	}

	function Get_exam_id($exam_code)
	{
		$this->query = "
		SELECT exam_id FROM exams 
		WHERE online_exam_code = '$exam_code'
		";

		$result = $this->query_result();

		foreach($result as $row)
		{
			return $row['exam_id'];
		}
	}

	function Get_exam_code($exam_id)
	{
		$this->query = "
		SELECT online_exam_code FROM exams 
		WHERE exam_id = '$exam_id'
		";

		$result = $this->query_result();

		foreach($result as $row)
		{
			return $row['online_exam_code'];
		}
	}


	function Upload_file()
	{
		// if(!empty($this->filedata['name']))
			// $extension = pathinfo($this->filedata['name'], PATHINFO_EXTENSION);

			// $new_name = uniqid() . '.' . $extension;

			// $_source_path = $this->filedata['tmp_name'];

			// $target_path = './upload/' . $new_name;

			// move_uploaded_file($_source_path, $target_path);

			// return $new_name;
			$extension = pathinfo($imageName, PATHINFO_EXTENSION);
			$tempname = $_FILES["exam_image"]["tmp_name"];	
			$newname = $online_exam_code . '.' . $extension;
			$folder = SITE_ROOT . "/upload/" . $newname;
			$root = SITE_ROOT;	
			
			move_uploaded_file($tempname, $folder);	
	}

	function user_session_private()
	{
		if(!isset($_SESSION['user_id']))
		{
			$this->redirect('login.php');
		}
	}

	function user_session_public()
	{
		if(isset($_SESSION['user_id']))
		{
			$this->redirect('index.php');
		}
	}

	function Fill_exam_list()
	{
		$this->query = "
		SELECT exam_id, exam_title 
			FROM exams 
			ORDER BY exam_title ASC
		";
		$result = $this->query_result();
		$output = '';
		foreach($result as $row)
		{
			$output .= '<option value="'.$row["exam_id"].'">'.$row["exam_title"].'</option>';
		}
		return $output;
	}

	function Get_user_question_option($question_id, $user_id)
	{
		$this->query = "
		SELECT user_selection FROM selections 
		WHERE question_id = '".$question_id."' 
		AND user_id = '".$user_id."'
		";
		$result = $this->query_result();
		foreach($result as $row)
		{
			return $row["user_selection"];
		}
	}

	function Get_question_answer_option($question_id)
	{
		$this->query = "
		SELECT answer_option FROM questions 
		WHERE question_id = '".$question_id."' 
		";

		$result = $this->query_result();

		foreach($result as $row)
		{
			return $row['answer_option'];
		}
	}

	function clean_search_results($search) {
		$search = preg_replace('/\s\s+/', ' ',$search);
		$search = trim($search);
		return $search;
	}

	function Get_exam_status($exam_id)
	{
		$this->query = "
		SELECT online_exam_status FROM exams 
		WHERE exam_id = '".$exam_id."' 
		";
		$result = $this->query_result();
		foreach($result as $row)
		{
			return $row["online_exam_status"];
		}
	}
	function Get_user_exam_status($exam_id, $user_id)
	{
		$this->query = "
		SELECT attendance_status 
		FROM user_exam_enroll_table 
		WHERE exam_id = '$exam_id' 
		AND user_id = '$user_id'
		";
		$result = $this->query_result();
		foreach($result as $row)
		{
			return $row["attendance_status"];
		}
	}
}

?>