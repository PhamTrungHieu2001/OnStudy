<?php

//question.php

include('header.php');
$exam_title = $exam->Get_exam_title($_GET['code']);

?>
<br />
<nav aria-label="breadcrumb">
  	<ol class="breadcrumb">
    	<li class="breadcrumb-item"><a href="exam.php">Exam List</a></li>
    	<li class="breadcrumb-item active" aria-current="page">Question List</li>
  	</ol>
</nav>
<div class="card">
	<div class="card-header">
		<div class="row">
			<div class="col-md-9">
				<h3 class="panel-title"><?php echo $exam_title?></h3>
			</div>
			<div class="col-md-3" align="right">
				<button type="button" id="add_question" class="btn btn-info btn-sm">Add question</button>
				<!-- <div class="dropdown-menu">
					<button type="button" id="add_one_choice_question" class="btn btn-light w-100">Add one choice question</button>
					<button type="button" id="add_multiple_choice_question" class="btn btn-light w-100">Add multiple choice question</button>
				</div> -->
				<!-- <button type="button" id="delete_all_question_btn" class="btn btn-danger btn-sm mt-3">Delete all questions</button> -->
			</div>
		</div>
	</div>
	<!-- Display questions in the exam -->
	<div class="card-body">
		<span id="message_operation"></span>
		<div class="table-responsive">
			<table id="question_data_table" class="display">
				<thead>
					<tr>
						<th>No.</th>
						<th>Question Title</th>
						<th>Image</th>
						<th>Options</th>
						<th>Right Answer</th>
						<th>Action</th>
					</tr>
				</thead>
			</table>
		</div>
	</div>
</div>

<!-- ADD & EDIT QUESTION MODAL -->
<div class="modal" id="question_modal">
  	<div class="modal-dialog modal-lg">
    	<form method="post" id="question_form" enctype="multipart/form-data">
      		<div class="modal-content">
      			<!-- Modal Header -->
        		<div class="modal-header">
          			<h4 class="question_modal_title" id="question_modal_title">Add question</h4>
        		</div>
        		<!-- Modal body -->
        		<div class="modal-body">
          			<div class="form-group">
            			<div class="row">
              				<label class="col-md-4 text-right">Question Title <span class="text-danger">*</span></label>
	              			<div class="col-md-8">
	                			<input type="text" name="question_title" id="question_title" class="form-control" />
	                		</div>
            			</div>
          			</div>
					<!-- Question image -->
					<div class="form-group">
                        <div class="row">
                            <label class="col-md-4 text-right" for="question_image" id="upload_question_image">Upload question image</label>
                            <input type="file" name="question_image" id="question_image" accept="image/*">
                        </div>
						<div class="row justify-content-center p-3">
  							<img id="question_image_preview" src="#" alt="question image" class="w-25"/>
						</div>
						<div class="row" id="delete_question_image_row">
							<label class="col-md-4 text-right">Delete question image</label>
	              			<div class="col-md-8">
	                			<input type="checkbox" name="delete_question_image" id="delete_question_image"/>
	                		</div>
						</div>
                    </div>
					<!-- Option -->
          			<div class="form-group">
            			<div class="row" id="option_row">
              				<label class="col-md-4 text-right">Option 1 <span class="text-danger">*</span></label>
	              			<div class="col-md-8">
	                			<input type="text" name="option_title_1" id="option_title_1" class="form-control option_title" />
	                		</div>
							<label class="col-md-4 text-right mt-3">Option 2  <span class="text-danger">*</span></label>
	              			<div class="col-md-8">
	                			<input type="text" name="option_title_2" id="option_title_2" class="form-control option_title mt-3" />
	                		</div>
            			</div>
          			</div>
          			<div class="form-group">
            			<div class="row">
              				<label class="col-md-4 text-right">Answer <span class="text-danger">*</span></label>
	              			<div class="col-md-8">
	                			<select name="answer_options[]" id="answer_options" class="form-control" multiple>
									<option value="">Select</option>
	                				<option value="1">Option 1</option>
									<option value="2">Option 2</option>
	                			</select>
	                		</div>
            			</div>
          			</div>
        		</div>

	        	<!-- Modal footer => save values --> 
	        	<div class="modal-footer">
	        		<input type="hidden" name="question_id" id="question_id" />

	        		<input type="hidden" name="online_exam_id" id="hidden_online_exam_id" />

	        		<input type="hidden" name="page" value="question" />

	        		<input type="hidden" name="action" id="hidden_action" value="Add" />

					<input type="hidden" name="exam_code" value="">

					<input type="hidden" name="delete_image" value="no">

					<input type="hidden" name="total_option" value="">

					<button id="add_option_btn" type="button" class="btn btn-sm btn-primary">Add option</button>

	        		<input type="submit" name="question_submit_btn" id="question_submit_btn" class="btn btn-success btn-sm" value="Add" />

	          		<button type="button" class="btn btn-danger btn-sm" data-dismiss="modal">Close</button>
	        	</div>
        	</div>
    	</form>
  	</div>
</div>

<!-- DELETE QUESTION MODAL -->
<div class="modal" id="delete_question_modal">
  	<div class="modal-dialog">
    	<div class="modal-content">

      		<!-- Modal Header -->
      		<div class="modal-header">
        		<h4 class="modal-title">Delete Confirmation</h4>
        		<button type="button" class="close" data-dismiss="modal">&times;</button>
      		</div>

      		<!-- Modal body -->
      		<div class="modal-body">
        		<h3 align="center">Are you sure you want to remove this question?</h3>
      		</div>

      		<!-- Modal footer -->
      		<div class="modal-footer">
      			<button type="button" name="ok_button" id="ok_button" class="btn btn-success btn-sm">OK</button>
        		<button type="button" class="btn btn-danger btn-sm" data-dismiss="modal">Close</button>
      		</div>
    	</div>
  	</div>
</div>

<!-- DELETE ALL QUESTIONS MODAL -->
<!-- <div class="modal" id="delete_all_question_modal">
  	<div class="modal-dialog">
    	<div class="modal-content">

      		<div class="modal-header">
        		<h4 class="modal-title">Delete Confirmation</h4>
      		</div>

      		<div class="modal-body">
        		<h3 align="center">Are you sure you want to remove all questions in the exam?</h3>
      		</div>

      		<div class="modal-footer">
      			<button type="button" name="ok_all_button" id="ok_all_button" class="btn btn-primary btn-sm">OK</button>
        		<button type="button" class="btn btn-danger btn-sm" data-dismiss="modal">Close</button>
      		</div>
    	</div>
  	</div>
</div> -->

<script>

$(document).ready(function(){
	
var exam_code = "<?php echo $_GET["code"]; ?>";
const addOptionBtn = document.getElementById("add_option_btn");
const option_row = document.getElementById('option_row');
const answer_options = document.getElementById('answer_options');
const minRequiredOptions = 2;
let option_order = 0;
let question_id = '';


// Show all questions
var dataTable = $('#question_data_table').DataTable({
	"processing" :true,
	"serverSide" :true,
	"order" :[[0, 'asc']],
	"ajax" :{
		url:"ajax_action.php",
		method:"POST",
		data:{action:'fetch', page:'question', code:exam_code}
	},
	"columnDefs":[
		{
			"targets" : "_all",
			"orderable": false
		},
		{
			"width" : "20%",
			"targets" : 1
		},
		{
			"width" : "20%",
			"targets" : 2
		},
		{
			"width" : "25%",
			"targets" : 3
		},
		{
			"width" : "15%",
			"targets" : 4
		}
	],
});

// Reset add question form
function reset_add_question_form()
{
	$('#question_submit_btn').val('Add');
	$('#hidden_action').val('Add');
	$('#question_image_preview').attr("src", "#");
	$('.new_option').remove();
	$('.remove_option_btn').remove();
	option_order = minRequiredOptions;
	$('#delete_question_image_row').attr("style", "display: none");
	$('#question_form')[0].reset();
	$('#question_form').parsley().reset();
}

// reset edit question form
function reset_edit_question_form()
{
	$('#question_submit_btn').val('Save');
	$('#hidden_action').val('Edit');
	$('.new_option').remove();
	$('.remove_option_btn').remove();
	$('#delete_question_image_row').attr("style", "display: flex");
	$('#question_form')[0].reset();
	$('#question_form').parsley().reset();
}


// Add multiple choice question
$(document).on('click', '#add_question', function(){
	reset_add_question_form();
	$('#question_modal').modal('show');
	$('#message_operation').html('');
	exam_id = $(this).attr('id');
	$('#hidden_online_exam_id').val(exam_id);
});


function setAttributes(el, attrs) {
    Object.keys(attrs).forEach(key => el.setAttribute(key, attrs[key]));
}

// -- MANAGE QUESTION IMAGE --
// add & edit question image
$('#question_image').change(function(){
	const file = this.files[0];
	console.log(file);
	if (file) {
		let reader = new FileReader();
		reader.onload = function(event){
		console.log(event.target.result);
		$('#question_image_preview').attr('src', event.target.result);
		}
		reader.readAsDataURL(file);
	}
	else {
		$('#question_image_preview').attr('src', "#");
	}
});

// delete question image
$('#delete_question_image').change(function() {
	if ($(this).is(':checked')) {
		$("input[name='delete_image']").val('yes');
	}
	else {
		$("input[name='delete_image']").val('no');
	}
});


function addOption(option_order) {
	// option label
	let option_label = document.createElement('label');
	option_label.innerHTML = "Option " + option_order;
	setAttributes(option_label, {id: 'option_label_' + option_order, class: 'col-md-4 text-right new_option mt-3'});

	// option div
	let input_div = document.createElement('div');
	setAttributes(input_div, {id: 'input_div_' + option_order, class: 'col-md-7 pr-1 new_option'});

	// option input 
	let option_input = document.createElement('input');
	let input_name = 'option_title_' + option_order;
	setAttributes(option_input, {type: 'text', name: input_name, id: input_name, class: 'form-control option_title mt-3'});
	
	// option remove button 
	let remove_option_btn = document.createElement('button');
	setAttributes(remove_option_btn, {type: 'button', class: 'btn btn-danger btn-sm remove_option_btn mt-3', id: 'remove_'+ option_order});
	remove_option_btn.innerHTML = 'x';	
	
	// add a new option to <select>
	let option_select = document.createElement('option');
	option_select.innerHTML = "Option " + option_order;
	setAttributes(option_select, {value: option_order, class: "new_option"});

	// add all elements to form 
	option_row.append(option_label, input_div, remove_option_btn);
	input_div.append(option_input);
	answer_options.append(option_select);

	// focus on the new input
	option_input.focus();
}

// -- MANAGE OPTION --
$('#add_option_btn').on('click', function() {
	// add a new option to the form
	option_order++;

	addOption(option_order);
});

// remove option button -> option_order-- 
$('#option_row').on('click', '.remove_option_btn', (e) => {
	// delete option
	// console.log(e.target);
	let option_remove = e.target.id.split("_")[1];
	removeOptionElements(option_remove);
	option_remove++;
	// change below options attributes 
	while($('#option_label_' + option_remove).length > 0) {
		changeOptionAttributes(option_remove);
		option_remove++;
	}
	option_order--;
});

// change option elements id
function changeOptionAttributes(option_remove) {
	let new_order = option_remove - 1;
	$('#option_label_' + option_remove)[0].innerHTML = "Option " + new_order;
	// change id & name
	$('#option_label_' + option_remove).prop("id", "option_label_" + new_order);	
	$('#input_div_' + option_remove).prop("id", "input_div_" + new_order);	
	$('#option_title_' + option_remove).attr("name", "option_title_" + new_order);	
	$('#option_title_' + option_remove).prop("id", "option_title_" + new_order);
	$('#remove_' + option_remove).prop("id", "remove_" + new_order);	
	$("#answer_options option[value = " + option_remove + "]").val(new_order);
	$("#answer_options option[value = " + new_order + "]").html("Option " + new_order);
}

function removeOptionElements(option_remove) {
	$('#option_label_' + option_remove).remove();
	$('#option_title_' + option_remove).remove();
	$('#input_div_' + option_remove).remove();
	$('#remove_' + option_remove).remove();
	$("#answer_options option[value = " + option_remove + "]").remove();
}


// -- EDIT QUESTION --
$(document).on('click', '.edit', function(){
	$('#message_operation').html('');
	question_id = $(this).attr('id');
	reset_edit_question_form();

	$.ajax({
		url:"ajax_action.php",
		method:"POST",
		data:{action:'edit_fetch', question_id:question_id, page:'question'},
		dataType:"json",
		// add info to question modal
		success:function(data)
		{
			$('#question_title').val(data.question_title);
			$('#question_image_preview').attr("src", data.question_image);
			// add info to the first 2 options
			// console.log(data);
			for (let i=1; i<=minRequiredOptions; i++) {
				$('#option_title_' + i).val(data["option_title_" + i]);
			}
			if (data.total_option > minRequiredOptions) {
				for (let i=minRequiredOptions+1; i<=data.total_option; i++) {
					addOption(i);
					$('#option_title_' + i).val(data["option_title_" + i]);
				}
			}
			$('#answer_options').val(data.answer_option);
			$('#question_id').val(question_id);
			$('#question_modal_title').text('Edit question');
			$('#question_modal').modal('show');
			option_order = data.total_option;
		}
	})
});

// Submit add & edit question form
$('#question_submit_btn').on('click', function(event) {
	event.preventDefault();

	$('#question_title').attr('required', 'required');
	$('.option_title').attr('required', 'required');
	$('#answer_options').attr('required', 'required');

	if($('#question_form').parsley().validate())
	{ 
		let formData = new FormData($('#quetion_form')[0]);
		formData.append('page', 'question');
		formData.append('action', $('#hidden_action').val());
		formData.append('question_id', question_id);

		// append question_title
		formData.append('question_title', $("#question_title").val());
		// append question_image
		if ($('input[type=file]')[0].files[0] != undefined) {
			formData.append('question_image', $("#question_form input[type='file']")[0].files[0]);
		}
		else {
			formData.append('question_image', '');
		}
		// delete image option
		formData.append('delete_question_image', $("input[name='delete_image']").val());
		// append option, answer
		for (let i=1; i<=option_order; i++) {
			formData.append('option_title_' + i, $('#option_title_' + i).val());
		}
		formData.append('answer_options', $('#answer_options').val());
		formData.append('total_option', option_order);
		formData.append('exam_code', exam_code);
		// display values in formData
		for (var p of formData) {
			let name = p[0];
			let value = p[1];
			console.log(name, value)
		}

		$.ajax({
			url:"ajax_action.php",
			method:"POST",
			data: formData,
			dataType:"json",
			processData: false,
    		contentType: false,
			beforeSend:function(){
				$('#question_submit_btn').attr('disabled', 'disabled');
				$('#question_submit_btn').val('Validate...');
			},
			success:function(data)
			{
				if(data.success)
				{
					$('#message_operation').html('<div class="alert alert-success">'+data.success+'</div>');
					reset_add_question_form();
					dataTable.ajax.reload();
					$('#question_modal').modal('hide');
				}
				$('#question_submit_btn').attr('disabled', false);
				$('#question_submit_btn').val($('#hidden_action').val());
			}
		});
	}
});

// -- DELETE QUESTION --
$(document).on('click', '.delete', function(){
	question_id = $(this).attr('id');
	$('#delete_question_modal').modal('show');
});

// confirm delete question
$('#ok_button').click(function(){
	$.ajax({
		url:"ajax_action.php",
		method:"POST",
		data:{question_id:question_id, action:'delete', page:'question', exam_code: exam_code},
		dataType:"json",
		success:function(data)
		{
			$('#delete_question_modal').modal('hide');
			dataTable.ajax.reload();
			$('#message_operation').html('<div class="alert alert-success">'+data.success+'</div>');
		}
	})
});

// delete all questions
// $('#delete_all_question_btn').on('click', function() {
// 	$('#delete_all_question_modal').modal('show');
// });

// $('#ok_all_button').click(function(){
// 	$.ajax({
// 		url:"ajax_action.php",
// 		method:"POST",
// 		data:{action:'delete_all_question', page:'question', exam_code: exam_code},
// 		dataType:"json",
// 		success:function(data)
// 		{
// 			$('#message_operation').html('<div class="alert alert-success">'+data.success+'</div>');
// 			$('#delete_all_question_modal').modal('hide');
// 			dataTable.ajax.reload();
// 		}
// 	})
// });

});


</script>
