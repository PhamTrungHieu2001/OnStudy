<?php

//exam.php

include('header.php');

// $exam = new Examination;

// $exam->admin_session_private();

?>
<br />
<!-- TABLE HEADER -->
<div class="card">
	<div class="card-header">
		<div class="row">
			<div class="col-md-9">
				<h3 class="panel-title">Online exams</h3>
			</div>
			<div class="col-md-3" align="right">
				<button type="button" id="create_exam_btn" class="btn btn-info btn-sm">Create new exam</button>
			</div>
		</div>
	</div>
	<div class="card-body">
		<span id="message_operation"></span>
		<div class="table-responsive">
			<table id="exam_data_table" class="display">
				<thead>
					<tr>
						<th>Image</th>
						<th>Exam Title</th>
						<th>Duration</th>
						<th>Total Questions</th>
						<th>Date</th>
						<th>View Question</th>
						<th>History</th>
						<th>Action</th>
					</tr>
				</thead>
			</table>
		</div>
	</div>
</div>

<!-- ADD & EDIT EXAM MODAL -->
<div class="modal" id="exam_modal">
  	<div class="modal-dialog modal-lg">
    	<form method="post" id="exam_form" enctype="multipart/form-data">
      		<div class="modal-content">
      			<!-- Modal Header -->
        		<div class="modal-header">
          			<h4 class="modal-title" id="modal_title"></h4>
        		</div>

        		<!-- Modal body -->
        		<div class="modal-body">
					<!-- Exam title -->
          			<div class="form-group">
            			<div class="row">
              				<label class="col-md-4 text-right">Exam Title <span class="text-danger">*</span></label>
	              			<div class="col-md-8">
	                			<input type="text" name="exam_title" id="exam_title" class="form-control" />
	                		</div>
            			</div>
          			</div>
					<!-- Exam duration -->
          			<div class="form-group">
            			<div class="row">
              				<label class="col-md-4 text-right">Exam Duration (minutes)<span class="text-danger">*</span></label>
							<div class="col-md-8">
	                			<input type="number" name="exam_duration" id="exam_duration" class="form-control" />
	                		</div>
            			</div>
          			</div>
					<!-- Exam image -->
					<div class="form-group">
                        <div class="row">
                            <label class="col-md-4 text-right" for="exam_image" id="upload_exam_image">Upload exam image</label>
                            <input type="file" name="exam_image" id="exam_image" accept="image/*">
                        </div>
						<div class="row justify-content-center p-3">
  							<img id="exam_image_preview" src="#" alt="exam image" class="w-25"/>
						</div>
						<div class="row" id="delete_exam_image_row">
							<label class="col-md-4 text-right">Delete exam image</label>
	              			<div class="col-md-8">
	                			<input type="checkbox" name="delete_exam_image" id="delete_exam_image"/>
	                		</div>
						</div>
                    </div>
					<!-- Exam questions -->
					<div class="form-group">
                        <div class="row">
                            <label class="col-md-4 text-right" for="question_list" id="upload_question_list">Upload question file (.xlsx)<span class="text-danger">*</span></label>
                            <input type="file" name="question_list" id="question_list" accept=".xlsx, .xls" required >
                        </div>
                    </div>
        		</div>

	        	<!-- Modal footer -->
	        	<div class="modal-footer">
	        		<input type="hidden" name="exam_id" id="exam_id" />
	        		<input type="hidden" name="page" value="exam" />
					<input type="hidden" name="delete_image" value="no">
	        		<input type="hidden" name="action" id="action" value="Add" />
	        		<input type="submit" name="exam_submit_btn" id="exam_submit_btn" class="btn btn-success btn-sm" value="Add" />
	          		<button type="button" class="btn btn-danger btn-sm" data-dismiss="modal">Close</button>
	        	</div>
        	</div>
    	</form>
  	</div>
</div>

<!-- DELETE EXAM MODAL -->
<div class="modal" id="delete_exam_modal">
  	<div class="modal-dialog">
    	<div class="modal-content">

      		<!-- Modal Header -->
      		<div class="modal-header">
        		<h4 class="modal-title">Delete confirmation</h4>
        		<button type="button" class="close" data-dismiss="modal">&times;</button>
      		</div>

      		<!-- Modal body -->
      		<div class="modal-body">
        		<h3 align="center">Are you sure you want to remove this?</h3>
      		</div>

      		<!-- Modal footer -->
      		<div class="modal-footer">
      			<button type="button" name="delete_exam_btn" id="delete_exam_btn" class="btn btn-success btn-sm">OK</button>
        		<button type="button" class="btn btn-danger btn-sm" data-dismiss="modal">Close</button>
      		</div>
    	</div>
  	</div>
</div>

<script>

const validImageTypes = ['image/gif', 'image/jpeg', 'image/png'];

$(document).ready(function(){
	// Show all exams
	// DataTable(): construction function
	let dataTable = $('#exam_data_table').DataTable({
	// all actions that DataTables performs (such as paging, searching and ordering) are handed off to an SQL engine to perform these actions on the large data set  => each draw of the table will result in a new Ajax request to get the required data.
		"processing" : true,
		"serverSide" : true,
		"order" : [], 	// define which column(s) and the ordering direction
		// No ordering applied by DataTables during initialisation 
		// -> The rows are shown in the order they are read by DataTables (the array of data from Ajax data source)
		
		"ajax" : {
			url: "ajax_action.php", // set the URL for where the Ajax request should be made.
			method:"POST",
			data:{action:'fetch', page:'exam'} // data to be sent to ajax_action.php
		},
		"columnDefs":[
			{
				"defaultContent": "-", 
				"targets": "_all", 
			},
			{
				"orderable":false,
				"targets":[0,1,5,6,7],
			},
			{ "width": "15%", "targets": 0 }
		],
	});

	// reset values in exam form
	function reset_form()
	{
		$('#modal_title').text('Add Exam Details');
		$('#exam_image_preview').attr('src', "#");
		$('#delete_exam_image_row').attr('style', 'display: none');
		$('#exam_submit_btn').val('Add');
		$('#question_list').attr('type', "file");
		$('#upload_question_list').attr('style', "display: inline");
		$('#action').val('Add');
		$('#exam_form')[0].reset();
		$('#exam_form').parsley().reset();
	}

	// Click on "Create new exam" button
	$('#create_exam_btn').click(function(){
		reset_form();
		$('#exam_modal').modal('show'); // Opens the modal
		$('#message_operation').html('');
	});

	// validate form
	$('#exam_form').parsley();

	// Preview exam image
	$('#exam_image').change(function(){
        const file = this.files[0];
        console.log(file);
        if (file) {
          let reader = new FileReader();
          reader.onload = function(event){
            console.log(event.target.result);
            $('#exam_image_preview').attr('src', event.target.result);
          }
          reader.readAsDataURL(file);
        }
		else {
			$('#exam_image_preview').attr('src', "#");
		}
    });

	// Delete existed exam image
	$('#delete_exam_image').change(function() {
		if ($(this).is(':checked')) {
			$("input[name='delete_image']").val('yes');
		}
		else {
			$("input[name='delete_image']").val('no');
		}
	});
	
	// Submit new exam / save edited exam
	$('#exam_form').on('submit', function(event){
		event.preventDefault();

		$('#exam_title').attr('required', 'required');
		$('#exam_duration').attr('required', 'required');

		if($('#exam_form').parsley().validate())
		{
			let formData = new FormData(this);
			for (var p of formData) {
				let name = p[0];
				let value = p[1];
				console.log(name, value)
			}

			$.ajax({
				url:"ajax_action.php",
				method:"POST",
				data: formData,
				dataType:"json",
				processData: false, 
				contentType: false, 
				beforeSend:function(){
					$('#exam_submit_btn').attr('disabled', 'disabled');
					$('#exam_submit_btn').val('Validate...');
				},
				success:function(data)
				{
					if(data.success)
					{
						$('#message_operation').html('<div class="alert alert-success">'+data.success+'</div>');
						reset_form();
						dataTable.ajax.reload(); // Reload the table data from the Ajax data source.
						$('#exam_modal').modal('hide');
					}
					$('#exam_submit_btn').attr('disabled', false);
					$('#exam_submit_btn').val($('#action').val());
				}
			});
		}
	});

	var exam_id = '';

	// Click on edit button to edit the exam
	$(document).on('click', '.edit', function(){
		exam_id = $(this).attr('id');
		$('#message_operation').html('');
		reset_form();
		$('#delete_image_row').attr('style', 'display: flex');

		$.ajax({
			url:"ajax_action.php",
			method:"POST",
			data:{action:'edit_fetch', exam_id:exam_id, page:'exam'},
			dataType:"json",
			success:function(data) // show to the modal
			{
				$('#exam_title').val(data.exam_title);

				$('#exam_duration').val(data.exam_duration);

				$('#exam_image_preview').attr("src", "upload/" + data.exam_image);

				if (data.exam_image == "") {
					$('#exam_image_preview').attr("src", "upload/default.jpg");
				}

				$('#question_list').attr('type', "hidden");

				$('#upload_question_list').attr('style', "display: none");

				$('#exam_id').val(exam_id);

				$('#modal_title').text('Edit Exam Details');

				$('#exam_submit_btn').val('Save');

				$('#action').val('Edit');

				$('#exam_modal').modal('show');
			}
		})
	});

	// Click on delete button to delete the exam
	$(document).on('click', '.delete', function(){
		exam_id = $(this).attr('id');
		$('#delete_exam_modal').modal('show');
	});

	// Confirm deleting the exam
	$('#delete_exam_btn').click(function(){
		$.ajax({
			url:"ajax_action.php",
			method:"POST",
			data:{exam_id:exam_id, action:'delete', page:'exam'},
			dataType:"json",
			success:function(data)
			{
				$('#message_operation').html('<div class="alert alert-success">'+data.success+'</div>');
				$('#delete_exam_modal').modal('hide');
				dataTable.ajax.reload();
			}
		})
	});
});

</script>

<?php

// include('footer.php');

?>