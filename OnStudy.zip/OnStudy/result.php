<?php

include('admin/Examination.php');

$exam = new Examination;

$exam->user_session_private();

$con = new mysqli("localhost","root","","onstudy");

include('header.php');

$exam_id = $_COOKIE["exam_id"];
$part = $_COOKIE["part"];
$user_id = $_SESSION["user_id"];

// check if table exists
// $exam->query = "SELECT *
// FROM INFORMATION_SCHEMA.TABLES
// WHERE TABLE_SCHEMA = 'onstudy' 
// AND TABLE_NAME = 'temp_questions'
// ";
// $check = $exam->total_row();

// if ($check == 0) {
//     $exam->query = "SELECT * FROM questions
//     WHERE exam_id = '$exam_id'
//     ";
//     $questions = $exam->query_result();
//     $total_question = $exam->total_row();    
// }
// else {   
    $exam->query = "SELECT * FROM temp_questions
    WHERE exam_id = '$exam_id'
    ";
    $questions = $exam->query_result();
    $total_question = $exam->total_row();     

?>

<!-- Display exam result -->
<div class="card">
    <div class="card-header">
        <div class="row">
            <div class="col-md-12">Online Exam Result</div>
        </div>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-bordered table-hover">
                <tr>
                    <th>No. </th>
                    <th>Question</th>
                    <th>Your answer</th>
                    <th>Right answer</th>
                    <th>Result</th>
                </tr>

                <?php
                $total_mark = 0;
                $count = 0;
                $history_id = 0;

                // prevent from inserting into database when page reloads
                if ($_COOKIE['finish'] == 'false') {
                    $exam->query = "INSERT INTO history (user_id, exam_id, part, score, finished_date)
                    VALUES ('$user_id', '$exam_id', '$part', '$total_mark', NOW())";
                    $exam->execute_query();  
                    $exam->query = "SELECT * FROM history WHERE user_id = '$user_id'
                    ORDER BY history_id DESC LIMIT 1";
                    $history = $exam->query_result();
                    foreach ($history as $row) {
                        $history_id = $row['history_id'];
                    }
                    setcookie("finish", "true");
                } 

                // compare user's selected options to answers
                foreach($questions as $question)
                {
                    $count++;
                    $exam->query = " SELECT * FROM options 
                    WHERE question_id = '".$question["question_id"]."'
                    ";
                    $sub_result = $exam->query_result();

                    $user_answer = '';
                    $orignal_answer = '';
                    $question_result = '';
                    $check = -1;

                    $exam->query = " SELECT * FROM selections
                    WHERE question_id = '".$question["question_id"]."'
                    AND user_id = '".$user_id."'
                    "; 
                    $result = $exam->query_result();
                    $selected = $exam->total_row(); 

                    // check if user has answered the question
                    if ($selected == 1) {
                        // loop through user's selected options
                        foreach($result as $row) {
                            // loop through options in db
                            foreach($sub_result as $sub_row)
                            {
                                // user_selection = "3,5"
                                // show user answer
                                if(str_contains($row['user_selection'], $sub_row["option_number"]))
                                {
                                    $user_answer .= $sub_row['option_title'];
                                    $user_answer .= "<br>";
                                }
                                // show right answer
                                if(str_contains($question['answer_option'], $sub_row['option_number']))
                                {
                                    $orignal_answer .= $sub_row['option_title'];
                                    $orignal_answer .= "<br>";
                                }
                            }

                            if($row['mark'] == 1)
                            {
                                $question_result = '<h4 class="badge badge-success">Right</h4>';
                            }

                            if($row['mark'] == 0)
                            {
                                $question_result = '<h4 class="badge badge-danger">Wrong</h4>';
                            }
                        }
                    }
                    else {
                        foreach($sub_result as $sub_row)
                        {
                            // show user answer
                            $user_answer = '';
                            // show right answer
                            if(str_contains($question['answer_option'], $sub_row['option_number']))
                            {
                                $orignal_answer .= $sub_row['option_title'];
                                $orignal_answer .= "<br>";
                            }
                        }
                        $question_result = '<h4 class="badge badge-danger">Wrong</h4>';                        
                    }

                    echo '
                    <tr>
                        <td>'.$count.'</td>
                        <td>'.$question['question_title'].'</td>
                    ';

                    echo '
                    <td>'.$user_answer.'</td>
                    <td>'.$orignal_answer.'</td>
                    <td>'.$question_result.'</td>
                </tr>
                    ';
                }
            
                $exam->query = "SELECT SUM(mark) as total_mark FROM selections 
                WHERE user_id = '".$user_id."' 
                AND exam_id = '".$exam_id."'
                ";
                $total_mark = $exam->query_result();
                $total_row = $exam->total_row();

                foreach($total_mark as $row)
                {
                    $total_mark = $row['total_mark'];
                }    
                if ($total_mark == '') {
                    $total_mark = 0;
                }
                                
                $exam->query = "UPDATE history SET score = '$total_mark' WHERE history_id = '$history_id'";
                $exam->execute_query();    
                ?>
                <tr>
                    <td colspan="4"><b>Total Score</b></td>
                    <td align="center"><b><?php echo $total_mark ?> / <?php echo $total_question ?></b></td>
                </tr>
            </table>
        </div>
    </div>
</div>
