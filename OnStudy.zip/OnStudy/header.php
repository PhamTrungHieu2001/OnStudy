<!DOCTYPE html>
<html lang="en">
<head>
  	<title>OnStudy</title>
  	<meta charset="utf-8">
  	<meta name="viewport" content="width=device-width, initial-scale=1">
  	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.19/css/dataTables.bootstrap4.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.4/css/jquery.dataTables.css" />
    <script src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.js"></script>
  	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
  	<script src="https://cdn.jsdelivr.net/gh/guillaumepotier/Parsley.js@2.9.1/dist/parsley.js"></script>
  	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.19/js/dataTables.bootstrap4.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
  	<link rel="stylesheet" href="style/style.css" />
    <link rel="stylesheet" href="style/TimeCircles.css" />
    <script src="style/TimeCircles.js"></script>
</head>
<body>
	<div class="jumbotron text-center" style="margin-bottom:0; padding: 1rem 1rem;">
    <img src="admin/logo.jpg" class="img-fluid" width="300" alt="Online Examination System in PHP" />
  </div>

<?php
$db_connection = new mysqli("localhost","root","","onstudy");

if(isset($_SESSION['user_id'])){
  $get_user = mysqli_query($db_connection, "SELECT * FROM `users` WHERE `user_id`= '".$_SESSION['user_id']."'");
  if(mysqli_num_rows($get_user) > 0){
    $user = mysqli_fetch_assoc($get_user);
  }
  else{
      header('Location: logout.php');
      exit;
  }

?>

<nav class="navbar navbar-expand-sm bg-info navbar-dark">
  <a class="navbar-brand" href="index.php"><i class="fa-solid fa-house"></i>  Home</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
  <span class="navbar-toggler-icon"></span>
  </button>
  <div class="navbar-collapse" id="collapsibleNavbar">
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" href="history.php"><i class="fa-regular fa-file-lines"></i> History</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="profile.php"><i class="fa-regular fa-user"></i> <?php echo $user['user_name']; ?></a>
      </li>        
      <img style="max-width: 15%" src="<?php echo $user['profile_image']; ?>" alt="<?php echo $user['user_name']; ?>">
    </ul>
  </div> 

  <a class="text-white float-right m-2" href="logout.php">Log Out <i class="fa-solid fa-arrow-right-from-bracket"></i></a> 
  
</nav>

<div class="container-fluid">

<?php 
}
?>

<script>
$('a').each(function(){
  if ($(this).prop('href') == window.location.href) {
      $(this).addClass('page-active'); 
      $(this).parents('li').addClass('page-active');
  }
});
</script>
