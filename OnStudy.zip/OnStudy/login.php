<?php

//login.php

require 'admin/Examination.php';

$exam = new Examination;

$exam->user_session_public();

require 'header.php';

require 'api/vendor/autoload.php';

$db_connection = new mysqli("localhost","root","","onstudy");

$current_datetime = date("Y-m-d") . ' ' . date("H:i:s", STRTOTIME(date('h:i:sa')));

// Creating new google client instance
$client = new Google_Client();

// Enter your Client ID
$client->setClientId('374974839866-oesjmsld5dif86rkqnuq82t2f5167cas.apps.googleusercontent.com');
// Enter your Client Secrect
$client->setClientSecret('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');
// Enter the Redirect URL
$client->setRedirectUri('http://localhost:8080/OnStudy/login.php');

// Adding those scopes which we want to get (email & profile Information)
$client->addScope("email");
$client->addScope("profile");

if(isset($_GET['code'])){

    $token = $client->fetchAccessTokenWithAuthCode($_GET['code']);

    if(!isset($token["error"])){

        $client->setAccessToken($token['access_token']);

        // getting profile information
        $google_oauth = new Google_Service_Oauth2($client);
        $google_account_info = $google_oauth->userinfo->get();

        // Storing data into database
        $id = mysqli_real_escape_string($db_connection, $google_account_info->id);
        $full_name = mysqli_real_escape_string($db_connection, trim($google_account_info->name));
        $email = mysqli_real_escape_string($db_connection, $google_account_info->email);
        $profile_image = mysqli_real_escape_string($db_connection, $google_account_info->picture);
        
        // checking user already exists or not
        $get_user = mysqli_query($db_connection, "SELECT `user_id` FROM `users` WHERE `google_id`='$id'");
        if(mysqli_num_rows($get_user) > 0){
            $result = mysqli_query($db_connection, "SELECT `user_id` FROM `users` WHERE `google_id`='$id'");
            foreach($result as $row) {
                $user_id = $row['user_id'];
            }
            $_SESSION['user_id'] = $user_id; 
            header('Location: index.php');
            exit;
        }

        else{
            // if user not exists we will insert the user
            $insert = mysqli_query($db_connection, "INSERT INTO `users`(`google_id`,`user_name`,`user_email_address`, profile_image, created_time) VALUES ('$id','$full_name','$email', '$profile_image', '$current_datetime')");
            if($insert){
                $result = mysqli_query($db_connection, "SELECT `user_id` FROM `users` WHERE `google_id`='$id'");
                foreach($result as $row) {
                    $user_id = $row['user_id'];
                }    
                $_SESSION['user_id'] = $user_id; 
                header('Location: index.php');
                exit;
            }
            else{
                echo "Sign up failed!(Something went wrong).";
            }
        }
    }
    else {
        header('Location: login.php');
        exit;
    }
}
?>

<div class="container">
    <br>
    <div class="row">
        <div class="col-md-3">

        </div>
        <!-- <div class="col-md-6" style="margin-top:100px;">
            <div class="card">
                <div class="card-header">User Login</div>
                <div class="card-body">
                    <form method="post" id="user_login_form">
                        <div class="form-group">
                            <label>Enter Email Address</label>
                            <input type="text" name="user_email_address" id="user_email_address" class="form-control" />
                        </div>
                        <div class="form-group">
                            <label>Enter Password</label>
                            <input type="password" name="user_password" id="user_password" class="form-control" />
                        </div>
                        <div class="form-group">
                            <input type="hidden" name="page" value="login" />
                            <input type="hidden" name="action" value="login" />
                            <input type="submit" name="user_login" id="user_login" class="btn btn-info" value="Login" />
                        </div>
                    </form>
                    <div class="d-flex justify-content-between">
                      <div>Not a member?<a href="register.php"> Register</a></div>
                      <a href="forget_password.php">Forgot password?</a>
                    </div>
                </div>
            </div>
        </div> -->
        <div class="col-md-6 text-center">
        <a type="button" class="btn btn-lg btn-outline-primary" href="<?php echo $client->createAuthUrl(); ?>">
        Sign in with <i class="fa-brands fa-google"></i>
        </a>
        </div>
    </div>
</div>

<script>
$(document).ready(function() {

    $('#user_login_form').parsley();

    $('#user_login_form').on('submit', function(event) {
        event.preventDefault();

        $('#user_email_address').attr('required', 'required');

        $('#user_email_address').attr('data-parsley-type', 'email');

        $('#user_password').attr('required', 'required');

        if ($('#user_login_form').parsley().validate()) {
            $.ajax({
                url: "user_ajax_action.php",
                method: "POST",
                data: $(this).serialize(),
                dataType: "json",
                beforeSend: function() {
                    $('#user_login').attr('disabled', 'disabled');
                    $('#user_login').val('please wait...');
                },
                success: function(data) {
                    if (data.success) {
                        location.href = 'index.php';
                    } else {
                        $('#message').html('<div class="alert alert-danger">' + data.error +
                            '</div>');
                    }

                    $('#user_login').attr('disabled', false);

                    $('#user_login').val('Login');
                }
            })
        }

    });
});
</script>