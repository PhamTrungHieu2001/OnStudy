<?php

include('admin/Examination.php');

$exam = new Examination;

$exam->user_session_public();

include('header.php');

?>

<div class="containter">
    <div class="row">
        <div class="col-md-3">
        </div>
        <div class="col-md-6" style="margin-top:20px;">
            <div class="card">
                <div class="card-header">
                    <h4>User Registration</h4>
                </div>
                <div class="card-body">
                    <span id="message"></span>
                    <form method="post" id="user_register_form">
                        <div class="form-group">
                            <label>Enter Email Address</label>
                            <input type="text" name="user_email_address" id="user_email_address" class="form-control"
                                data-parsley-checkemail
                                data-parsley-checkemail-message='Email Address already Exists' />
                        </div>
                        <div class="form-group">
                            <label>Enter Password</label>
                            <input type="password" name="user_password" id="user_password" class="form-control" />
                        </div>
                        <div class="form-group">
                            <label>Enter Confirm Password</label>
                            <input type="password" name="confirm_user_password" id="confirm_user_password"
                                class="form-control" />
                        </div>
                        <div class="form-group">
                            <label>Enter Name</label>
                            <input type="text" name="user_name" id="user_name" class="form-control" />
                        </div>
                        <br />
                        <div class="form-group" align="center">
                            <input type="hidden" name='page' value='register' />
                            <input type="hidden" name="action" value="register" />
                            <input type="submit" name="user_register" id="user_register" class="btn btn-info"
                                value="Register" />
                        </div>
                    </form>
                    <div align="center">
                        <a href="login.php">Login</a>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-3">
        </div>
    </div>
    <br /><br />
    <br /><br />
</div>

</body>

</html>

<script>
$(document).ready(function() {

    window.ParsleyValidator.addValidator('checkemail', {
        validateString: function(value) {
            return $.ajax({
                url: 'user_ajax_action.php',
                method: 'post',
                data: {
                    page: 'register',
                    action: 'check_email',
                    email: value
                },
                dataType: "json",
                async: false,
                success: function(data) {
                    return true;
                }
            });
        }
    });

    $('#user_register_form').parsley();

    $('#user_register_form').on('submit', function(event) {
        event.preventDefault();

        $('#user_email_address').attr('required', 'required');

        $('#user_email_address').attr('data-parsley-type', 'email');

        $('#user_password').attr('required', 'required');

        $('#confirm_user_password').attr('required', 'required');

        $('#confirm_user_password').attr('data-parsley-equalto', '#user_password');

        $('#user_name').attr('required', 'required');

        $('#user_name').attr('data-parsley-pattern', '^[a-zA-Z ]+$');

        if ($('#user_register_form').parsley().validate()) {
            $.ajax({
                url: 'user_ajax_action.php',
                method: "POST",
                data: new FormData(this),
                dataType: "json",
                contentType: false,
                cache: false,
                processData: false,
                beforeSend: function() {
                    $('#user_register').attr('disabled', 'disabled');
                    $('#user_register').val('Please wait...');
                },
                success: function(data) {
                    if (data.success) {
                        $('#message').html(
                            '<div class="alert alert-success">Register successful!</div>'
                            );
                        $('#user_register_form')[0].reset();
                        $('#user_register_form').parsley().reset();
                    }

                    $('#user_register').attr('disabled', false);

                    $('#user_register').val('Register');
                }
            })
        }

    });

});
</script>