<?php

//user_ajax_action.php

include('admin/Examination.php');

// require_once('class/class.phpmailer.php');

$exam = new Examination;

$current_datetime = date("Y-m-d") . ' ' . date("H:i:s", STRTOTIME(date('h:i:sa')));

if(isset($_POST['page']))
{
	// if($_POST['page'] == 'register')
	// {
	// 	if($_POST['action'] == 'check_email')
	// 	{
	// 		$exam->query = "
	// 		SELECT * FROM users 
	// 		WHERE user_email_address = '".trim($_POST["email"])."'
	// 		";

	// 		$total_row = $exam->total_row();

	// 		if($total_row == 0)
	// 		{
	// 			$output = array(
	// 				'success'		=>	true
	// 			);
	// 			echo json_encode($output);
	// 		}
	// 	}

	// 	if($_POST['action'] == 'register')
	// 	{
	// 		// $user_verfication_code = md5(rand());

	// 		$receiver_email = $_POST['user_email_address'];

	// 		// $exam->filedata = $_FILES['user_image'];

	// 		// $user_image = $exam->Upload_file();

	// 		$exam->data = array(
	// 			':user_email_address'	=>	$receiver_email,
	// 			':user_password'		=>	password_hash($_POST['user_password'], PASSWORD_DEFAULT),
	// 			':user_name'			=>	$_POST['user_name'],
	// 			':created_time'		=>	$current_datetime
	// 		);

	// 		$exam->query = "
	// 		INSERT INTO users 
	// 		(user_email_address, user_password, user_name, created_time)
	// 		VALUES 
	// 		(:user_email_address, :user_password, :user_name, :created_time)
	// 		";

	// 		$exam->execute_query();

	// 		// $subject= 'Online Examination Registration Verification';

	// 		// $body = '
	// 		// <p>Thank you for registering.</p>
	// 		// <p>This is a verification eMail, please click the link to verify your eMail address by clicking this <a href="'.$exam->home_page.'verify_email.php?type=user&code='.$user_verfication_code.'" target="_blank"><b>link</b></a>.</p>
	// 		// <p>In case if you have any difficulty please eMail us.</p>
	// 		// <p>Thank you,</p>
	// 		// <p>Online Examination System</p>
	// 		// ';

	// 		// $exam->send_email($receiver_email, $subject, $body);

	// 		$output = array(
	// 			'success'		=>	true
	// 		);

	// 		echo json_encode($output);
	// 	}
	// }

	// if($_POST['page'] == 'login')
	// {
	// 	if($_POST['action'] == 'login')
	// 	{
	// 		$exam->data = array(
	// 			':user_email_address'	=>	$_POST['user_email_address']
	// 		);

	// 		$exam->query = "
	// 		SELECT * FROM users 
	// 		WHERE user_email_address = :user_email_address
	// 		";

	// 		$total_row = $exam->total_row();

	// 		if($total_row > 0)
	// 		{
	// 			$result = $exam->query_result();

	// 			foreach($result as $row)
	// 			{
	// 				if(password_verify($_POST['user_password'], $row['user_password']))
	// 				{
	// 					$_SESSION['user_id'] = $row['user_id'];

	// 					$output = array(
	// 						'success'	=>	true
	// 					);
	// 				}
	// 				else
	// 				{
	// 					$output = array(
	// 						'error'		=>	'Wrong Password'
	// 					);
	// 				}
	// 			}
	// 		}
	// 		else
	// 		{
	// 			$output = array(
	// 				'error'		=>	'Wrong Email Address'
	// 			);
	// 		}

	// 		echo json_encode($output);
	// 	}
	// }

	if($_POST['page'] == "profile")
	{
		if($_POST['action'] == "profile")
		{
			$exam->data = array(
				':user_name'				=>	$exam->clean_data($_POST['user_name']), 
				':user_id'					=>	$_SESSION['user_id']		
			);

			$exam->query = "UPDATE users 
			SET user_name = :user_name
			WHERE user_id = :user_id
			";
			$exam->execute_query();

			$output = array(
				'success'		=>	true
			);

			echo json_encode($output);
		}
	}

	// if($_POST['page'] == 'change_password')
	// {
	// 	if($_POST['action'] == 'change_password')
	// 	{
	// 		$exam->data = array(
	// 			':user_password'	=>	password_hash($_POST['user_password'], PASSWORD_DEFAULT),
	// 			':user_id'			=>	$_SESSION['user_id']
	// 		);

	// 		$exam->query = "
	// 		UPDATE users 
	// 		SET user_password = :user_password 
	// 		WHERE user_id = :user_id
	// 		";

	// 		$exam->execute_query();

	// 		session_destroy();

	// 		$output = array(
	// 			'success'		=>	'Password has been change'
	// 		);

	// 		echo json_encode($output);
	// 	}
	// }

	if($_POST["page"] == 'index') {
		if($_POST['action'] == 'fetch')
		{
			$output = array();
			$sort_query = '';
			$order_column = '';

			$exam->query = "SELECT * FROM exams WHERE ";

			// Search by title
			if(isset($_POST["search"]["value"]))
			{
				$search = $exam->clean_search_results($_POST["search"]["value"]);
			 	$exam->query .= 'exams.exam_title LIKE "%'.$search.'%" ';
			}

			// $exam->query .= ')';

			// Order
			if(isset($_POST["order"]))
			{
				if ($_POST['order']['0']['column'] == '2') {
					$sort_query = ' ORDER BY exam_duration '.$_POST['order']['0']['dir'].' ';
				}
				else if ($_POST['order']['0']['column'] == '3') {
					$sort_query = ' ORDER BY total_question '.$_POST['order']['0']['dir'].' ';
				}
				else if ($_POST['order']['0']['column'] == '4') {
					$sort_query = ' ORDER BY exam_created_time '.$_POST['order']['0']['dir'].' ';
				}
				$exam->query .= $sort_query;
			}
			else
			{
				$exam->query .= ' ORDER BY exams.exam_id DESC ';
			}

			$extra_query = ' ';

			// Limit
			if($_POST["length"] != -1)
			{
			 	$extra_query .= 'LIMIT ' . $_POST['start'] . ', ' . $_POST['length'];
			}

			$filterd_rows = $exam->total_row();

			$exam->query .= $extra_query;

			$result = $exam->query_result();

			$total_row = $exam->total_row();

			$data = array();

			foreach($result as $row)
			{
				$sub_array = array();
				$exam_image_url = $row['exam_image'];
				if ($exam_image_url == '') {
					$exam_image_url = "default.jpg";
				}
				$sub_array[] = '<img src="admin/upload/'.$exam_image_url.'" class="img-fluid">';
				$sub_array[] = html_entity_decode($row["exam_title"]);
				$sub_array[] = $row["exam_duration"] . ' minutes';
				$sub_array[] = $row["total_question"] . ' questions';
				$sub_array[] = date("d-m-Y", strtotime($row['exam_created_time']));
				$exam_id = $exam->Get_exam_id($row["online_exam_code"]);

				$action = '<a href="view_exam.php?code='.$row["online_exam_code"].'" class="btn btn-warning btn-sm">View Questions</a> &nbsp;';
				$sub_array[] = $action;
				$data[] = $sub_array;
				
				// delete history if user already took the exam
				$exam->query = "DELETE FROM selections
				WHERE user_id = '".$_SESSION['user_id']."'
				AND exam_id = '$exam_id' ";		
				$exam->execute_query();		
				
				// drop temp questions table
				$exam->query = "DROP TABLE IF EXISTS temp_questions";
				$exam->execute_query();
			}

			$output = array(
			 	"draw"    			=> 	intval($_POST["draw"]),
			 	"recordsTotal"  	=>  $total_row,
			 	"recordsFiltered" 	=> 	$filterd_rows,
			 	"data"    			=> 	$data,
			);
			echo json_encode($output);
		}
	}

	if($_POST["page"] == 'view_exam') {
		if($_POST['action'] == 'fetch') {
			$exam_id = $_POST["exam_id"];
			$exam->query = "SELECT * FROM questions 
			WHERE exam_id = '$exam_id' AND 
			";
			// Search by title
			if(isset($_POST["search"]["value"]))
			{
				$search = $exam->clean_search_results($_POST["search"]["value"]);
			 	$exam->query .= 'question_title LIKE "%'.$search.'%" ';
			}

			// $exam->query .= ')';

			// Order
			$exam->query .= ' ORDER BY question_id ASC ';

			$extra_query = ' ';

			// Limit
			if($_POST["length"] != -1)
			{
			 	$extra_query .= ' LIMIT ' . $_POST['start'] . ', ' . $_POST['length'];
			}

			$filterd_rows = $exam->total_row();

			$exam->query .= $extra_query;

			$result = $exam->query_result();

			$total_row = $exam->total_row();

			$data = array();
			$count = 0;
			$alphabet = range('A', 'Z');

			foreach ($result as $row) {
				$arr = array();
				$count++;
				$arr[] = $count;
				$arr[] = $row['question_title'];
				$options = '';
				$exam->query = "SELECT * FROM options o
				INNER JOIN questions q ON o.question_id = q.question_id
				WHERE q.exam_id = '$exam_id'
				AND o.question_id = '$row[question_id]'
				ORDER BY o.option_number;  
				";
				$sub_result = $exam->query_result();
				foreach ($sub_result as $index => $sub_row) {
					// get index of option -> get alphabet[index]
					if (!in_array($sub_row['option_title'][0], $alphabet)) {
						$options .= $alphabet[$index];
						$options .= ". ";
					}
					$options .= $sub_row['option_title'];
					$options .= "<br>";
					// nl2br($options);
				}
				$arr[] = $options;
				$data[] = $arr;
			}
			$exam->query = "DROP TABLE IF EXISTS temp_questions";
			$exam->execute_query();
			$output = array(
				"draw"    			=> 	intval($_POST["draw"]),
				"recordsTotal"  	=>  $total_row,
				"recordsFiltered" 	=> 	$filterd_rows,
				"data"    			=> 	$data
		   );
			echo json_encode($output);
		}
	}

	if($_POST['page'] == 'take_exam') {	
		$total_question = $exam->Get_exam_total_question($_POST["exam_id"]);
		$num_questions = $total_question;

		if ($_POST['part'] == 'random') {
			// create base table: temp_questions (if not exists)
			$exam->query = "CREATE TABLE IF NOT EXISTS temp_questions AS 
			SELECT * FROM questions 
			WHERE exam_id = '".$_POST["exam_id"]."'
			ORDER BY RAND()
			LIMIT 20
			";
			$exam->execute_query();
		}
		else {
			$offset = 0;
			if (isset($_POST['part'])) {
				$offset = 20*($_POST['part'] - 1);
				if (($total_question - 20*($_POST['part'] - 1)) < 30) {
					$num_questions = $total_question - 20*($_POST['part'] - 1);
				}
				else {
					$num_questions = 20;
				}
			}
	
			$query = "CREATE TABLE IF NOT EXISTS temp_questions AS
			SELECT * FROM questions
			WHERE exam_id = '".$_POST["exam_id"]."'
			ORDER BY question_id
			LIMIT :offset, :num_questions 
			";
			$statement = $exam->connect->prepare($query);
			$statement->bindParam(':offset', $offset, PDO::PARAM_INT);
			$statement->bindParam(':num_questions', $num_questions, PDO::PARAM_INT);
			$statement->execute();
			// select from temp table: questions
		}

		if($_POST['action'] == 'load_question')
		{
			
			$exam_id = $_POST["exam_id"];
			$current_question = '';
			$question_id = $_POST["question_id"];
			$question_order = 0;

			// select the first question if question_id is not specified
			if($_POST['question_id'] == '')
			{
				$exam->query = " SELECT * FROM temp_questions
				ORDER BY question_id ASC 
				LIMIT 1
				";
			}
			else
			{
				// $question_id = $_COOKIE["current_question"];
				$exam->query = " SELECT * FROM temp_questions 
				WHERE question_id = '".$question_id."' 
				";
			}

			if ($_POST['part'] != "random") {
				$exam->query = " SELECT * FROM temp_questions ";
			}

			$result = $exam->query_result();
			$total_row = $exam->total_row(); // number of question being displayed
			$output = '<form action="result.php" method="POST" id="user_answer_form">';
			
			// Display the question
			foreach($result as $row)
			{
				$question_id = $row['question_id'];
				
				$question_order++;
				if ($total_row > 1) {
					$output .= '<b id="question_'.$question_id.'">'.$question_order.'.</b>';
				}
				$output .= '
				<p>'.$row["question_title"].'</p>
				';
				if ($row['question_image'] != '') {
					$output .= '<img src = "admin/'.$row["question_image"].'" class="w-50 mb-3">';	
				}

				$output .= '
				<div class="row">
				';

				$exam->query = " SELECT * FROM options 
				WHERE question_id = '".$row['question_id']."'
				";
				$sub_result = $exam->query_result();
				$count = 1;

				// Display options
				foreach($sub_result as $sub_row)
				{
					// if question has 1 correct answer
					if (!str_contains($row['answer_option'], ',')) {
						$output .= '
						<div class="col-md-6 mb-3">
							<div>
								<label>
								<input type="radio" name="'.$row["question_id"].'" class="answer_option" 
								id = "'.$sub_row["option_id"].'"
								data-question_id="'.$row["question_id"].'" 
								data-id="'.$count.'"/> &nbsp;'.$sub_row["option_title"].'
								</label>
							</div>
						</div>
						';	
					}
					// if question has > 1 correct answer => display checkbox input
					else {
						$output .= '
						<div class="col-md-6 mb-3">
							<div>
								<label>
								<input type="checkbox" name="'.$row["question_id"].'" class="answer_option"
								id="'.$sub_row["option_id"].'"
								data-question_id="'.$row["question_id"].'" 
								data-id="'.$count.'" 
								/> &nbsp;'.$sub_row["option_title"].'
								</label>
							</div>
						</div>
						';	
					}
					$count++;
				}
				// add review checkbox
				$output .= '
				</div>
				<div class="row"><input type="checkbox" name="review_checkbox" 
				class="mx-3 mb-3 review_checkbox" data-question_id="'.$row["question_id"].'"><label for="review_checkbox">Review</label></div>
				<hr />
				<input type="hidden" name="exam_id" id="exam_id" value='.$exam_id.'>
				';
				if ($total_row == 1) {
					$output .= '
					<input type="submit" value="Submit exam" class="btn btn-warning btn-lg">
					</form>
					';
				}
			}
			if ($total_row > 1) {
				$output .= '
				<input type="submit" value="Submit exam" class="btn btn-warning btn-lg">
				</form>
				';
			}
			
			$output .= "<script>
			let question_id = '$question_id';
			const total_question_display = '$total_row';
			if (total_question_display > 1) {
				question_id = '';
			}
			localStorage.setItem('current_question', question_id);
			$(document).ready(function() {
				// console.log(localStorage.getItem('checkbox_' + question_id));
				// change when user check/uncheck review button			
				$('.review_checkbox').change(function() {
					// get question_id from review checkbox
					let question_review_id = $(this).attr('data-question_id'); 
					if ($(this).is(':checked')) {
						$('#' + question_review_id).addClass('btn-secondary');
						localStorage.setItem('checkbox_' + question_review_id, 'true');
					}
					else {
						$('#' + question_review_id).removeClass('btn-secondary');
						localStorage.setItem('checkbox_' + question_review_id, 'false');
						if (localStorage.getItem(question_review_id) && !$('#' + question_review_id).hasClass('btn-primary')) {
							$('#' + question_review_id).addClass('btn-primary');
						}
					}
				});	
				// reselect option after reload page
				for (const [key, value] of Object.entries(localStorage)) {
					if (key.match(/^\d/) && value != '') {
						let options = localStorage.getItem(key).split(',');
						for (let option of options) {
							$('#' + option).prop('checked', true);
						}
					}
				}
				// add secondary class if review button is checked & check review button again
				for (const [key, value] of Object.entries(localStorage)) {
					if(key.startsWith('checkbox') && value == 'true') {
						let question_review_id = key.split('_')[1];
						$('input.review_checkbox[data-question_id= ' + question_review_id + ']').prop('checked', true);
					}
				}
			}); 
			</script>";

			echo $output;
		}

		if($_POST['action'] == 'question_navigation')
		{
			$exam->query = " SELECT question_id FROM temp_questions 
			WHERE exam_id = '".$_POST["exam_id"]."' 
			ORDER BY question_id ASC 
			";
			$result = $exam->query_result();
			$output = '
				<div class="card">
					<div class="card-header">Question Navigation</div>
					<div class="card-body">
						<div class="row">
			';
			$count = 1;
			// display all questions
			foreach($result as $row)	
			{
				$question_id = $row["question_id"];
				$output .= '
				<div class="col-md-2" style="margin-bottom:24px;">
					<button type="button" class="btn btn-md question_navigation" 
					id="'.$question_id.'" data-question_id="'.$question_id.'"
					>'.$count.'</button>
				</div>
				';
				$count++;
			}
			$output .= '
				</div>
			</div></div>
			';
			$output .= '
			<script>
			// if reload page -> add secondary/primary class to question navigation
			for (const [key, value] of Object.entries(localStorage)) {
				if (key.startsWith("checkbox")) {
					let arr = key.split("_");
					let question_id = arr[1];
					// if review is checked
					if (localStorage.getItem(key) == "true") {
						$("#" + question_id).addClass("btn-secondary");
					}
				}
				// if key starts with a number
				else if (key.match(/^\d/) && value != "") {
					$("#" + key).addClass("btn-primary");
				}
			}
			if (localStorage.getItem("current_question") != "") {
				$("#" + localStorage.getItem("current_question")).addClass("glow");
			}

			</script>
			';
			echo $output;
		}

		// save user's selected option
		if($_POST['action'] == 'answer')
		{
			$user_id = $_SESSION["user_id"];
			$exam_id = $_POST["exam_id"];
			$question_id = $_POST["question_id"];
			$user_answer = $_POST["answer_option"];
			$correct_answer = $exam->Get_question_answer_option($question_id);
			$mark = 0;
			
			$exam->query = "SELECT * FROM selections 
			WHERE user_id = '$user_id' AND exam_id = '$exam_id' AND question_id = '$question_id'
			";
			$count = $exam->total_row();
			// if not exists -> create then update
			if ($count == 0) {
				$exam->query = "INSERT INTO selections 
				(user_id, exam_id, question_id, user_selection, mark)
				VALUES ('$user_id', '$exam_id', '$question_id', '$user_answer', '$mark')
				";
				$exam->execute_query();
			}
			// if answer is correct
			if($user_answer == $correct_answer)
			{
				$mark = 1;
			}

			$exam->data = array(
				':user_selection'	=>	$user_answer,
				':mark'				=>	$mark
			);
			// save mark per question
			$exam->query = " UPDATE selections 
			SET user_selection = :user_selection, mark = :mark 
			WHERE user_id = '$user_id' 
			AND exam_id = '$exam_id' 
			AND question_id = '$question_id'
			";
			$exam->execute_query();
		}
	}

	if($_POST['page'] == 'history') {
		if ($_POST['action'] == 'fetch') {
			$exam->query = "SELECT exam_title, exams.exam_id, COUNT(history_id) as attempts, MAX(finished_date) as completed_date 
			FROM history INNER JOIN exams 
			ON history.exam_id = exams.exam_id
			WHERE user_id = '".$_SESSION['user_id']."' AND (
			";
			// Search by title
			if(isset($_POST["search"]["value"]))
			{
			 	$exam->query .= ' exams.exam_title LIKE "%'.$_POST["search"]["value"].'%" ';
			}

			$exam->query .= ' ) GROUP BY (history.exam_id)';

			// Order
			if(isset($_POST["order"]))
			{
				if ($_POST['order']['0']['column'] == '2') {
					$sort_query = ' ORDER BY attempts '.$_POST['order']['0']['dir'].' ';
				}
				if ($_POST['order']['0']['column'] == '3') {
					$sort_query = ' ORDER BY completed_date '.$_POST['order']['0']['dir'].' ';
				}
				$exam->query .= $sort_query;
			}
			else
			{
				$exam->query .= ' ORDER BY history.exam_id DESC ';
			}

			$extra_query = ' ';

			// Limit
			if($_POST["length"] != -1)
			{
			 	$extra_query .= 'LIMIT ' . $_POST['start'] . ', ' . $_POST['length'];
			}
			
			$filterd_rows = $exam->total_row();

			$exam->query .= $extra_query;

			$result = $exam->query_result();
						
			$total_row = $exam->total_row();

			$data = array();

			$count = 0;

			foreach ($result as $row) {
				$sub_array = array();
				$count++;
				$sub_array[] = $count;
				$sub_array[] = $row['exam_title'];
				$sub_array[] = $row['attempts'];
				$sub_array[] = $row['completed_date'];
				$sub_array[] = '<a href="attempt.php?id='.$row['exam_id'].'" class="btn btn-warning btn-sm">View attempts</a> &nbsp;';
				$data[] = $sub_array;
			}
			$output = array(
				"draw"    			=> 	intval($_POST["draw"]),
				"recordsTotal"  	=>  $total_row,
				"recordsFiltered" 	=> 	$filterd_rows,
				"data"    			=> 	$data,
		   );
		   echo json_encode($output);
		}
	}

	if($_POST['page'] == 'attempt') {
		$exam->query = "SELECT * FROM history 
		WHERE user_id = '".$_SESSION['user_id']."' AND exam_id = '".$_POST['id']."'
		";
		// Search by title
		// if(isset($_POST["search"]["value"]))
		// {
		//  	$exam->query .= ' exams.exam_title LIKE "%'.$_POST["search"]["value"].'%" ';
		// }

		// $exam->query .= ' ) GROUP BY (history.exam_id)';

		// Order
		if(isset($_POST["order"]))
		{
			if ($_POST['order']['0']['column'] == '2') {
				$sort_query = ' ORDER BY score '.$_POST['order']['0']['dir'].' ';
			}
			if ($_POST['order']['0']['column'] == '3') {
				$sort_query = ' ORDER BY finished_date '.$_POST['order']['0']['dir'].' ';
			}
			$exam->query .= $sort_query;
		}
		else
		{
			$exam->query .= ' ORDER BY history_id DESC ';
		}

		$extra_query = ' ';

		// Limit
		if($_POST["length"] != -1)
		{
			$extra_query .= 'LIMIT ' . $_POST['start'] . ', ' . $_POST['length'];
		}
		
		$filterd_rows = $exam->total_row();

		$exam->query .= $extra_query;

		$result = $exam->query_result();
					
		$total_row = $exam->total_row();

		$data = array();

		$count = 0;

		foreach ($result as $row) {
			$sub_array = array();
			$count++;
			$sub_array[] = $count;
			$sub_array[] = $row['part'];
			$sub_array[] = $row['score'];
			$sub_array[] = $row['finished_date'];
			$data[] = $sub_array;
		}
		$output = array(
			"draw"    			=> 	intval($_POST["draw"]),
			"recordsTotal"  	=>  $total_row,
			"recordsFiltered" 	=> 	$filterd_rows,
			"data"    			=> 	$data,
		);
		echo json_encode($output);
	}	
}

?>