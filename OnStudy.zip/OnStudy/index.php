<?php

include('admin/Examination.php');

$exam = new Examination;

$exam->user_session_private();

include('header.php');

setcookie("finish", "false");

?>

<br />
<div class="card">
	<div class="card-header">
		<div class="row">
			<div class="col-md-9">
				<h3 class="panel-title">Online exams</h3>
			</div>
		</div>
	</div>
	<div class="card-body">
		<div class="table-responsive">
			<table id="user_exam_table" class="display">
				<thead>
					<tr>
						<th>Image</th>
						<th>Exam Title</th>
						<th>Duration</th>
						<th>Total Questions</th>
						<th>Date</th>
						<th>Action</th>
					</tr>
				</thead>
			</table>
		</div>
	</div>
</div>

<script>

localStorage.clear();

$(document).ready(function(){

	let dataTable = $('#user_exam_table').DataTable({
		"processing" : true,
		"serverSide" : true,
		"autoWidth": false,
		"order" : [],
		"ajax" : {
			url:"user_ajax_action.php",
			type:"POST",
			data:{action:'fetch', page:'index'}
		},
		"columnDefs":[
			{
				"defaultContent": "-", 
				"targets": "_all", 
			},
			{
				"orderable": false,
				"targets": [0, 1, 5],
			},
			{ 
				"width": "15%",
				"targets": 0
			}
		],
	});

});

</script>

