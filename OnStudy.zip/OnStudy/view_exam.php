<?php

//view_exam.php

include('admin/Examination.php');

$exam = new Examination;

$exam->user_session_private();

include('header.php');

if(isset($_GET['code']))
{
    $exam_code = $_GET['code'];
	$exam_id = $exam->Get_exam_id($exam_code);
    $exam_title = $exam->Get_exam_title($exam_code);
    $total_question = $exam->Get_exam_total_question($exam_id);
}
?>

</br>

<body>
    <div>
        <div class="alert alert-primary">
        Để ôn tập hiệu quả các bạn có thể ôn theo từng phần (mỗi phần có khoảng 10-30 câu/20 phút) trong bộ câu hỏi này bằng cách trả lời các câu hỏi và xem lại đáp án. 
        Sau đó các bạn hãy chọn mục "Trộn đề ngẫu nhiên" (20 câu/20 phút) để ôn tập lại kiến thức đã ôn. Chúc các bạn thành công!
        </div>
        <button type="button" id="take_exam" class="btn btn-info btn-sm dropdown-toggle" data-toggle="dropdown"
            aria-haspopup="true" aria-expanded="false">Practice</button>
        <div class="dropdown-menu" id="exam-part-dropdown">
        </div>
        <!-- <a href="take_exam.php?code=<?php echo $exam_code;?>" class="btn btn-primary btn-sm">Take Exam</a> -->
        <a href="take_exam.php?code=<?php echo $exam_code;?>&part=random" class="btn btn-warning btn-sm" 
        data-toggle="tooltip" data-placement="right" title="20 câu">Random</a>
    </div>
    <br>
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="index.php">Exam List</a></li>
            <li class="breadcrumb-item active" aria-current="page">Question List</li>
        </ol>
    </nav>

    <div class="card mt-3">
        <div class="card-header">
            <h2><?php echo $exam_title;?></h2>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered table-striped table-hover" id="questions_table">
                    <thead>
                        <tr>
                            <th>No.</th>
                            <th>Question title</th>
                            <th>Options</th>
                        </tr>
                    </thead>
                </table>
            </div>
        </div>
    </div>
</body>

<script>
$(document).ready(function() {

    const exam_id = "<?php echo $exam_id; ?>";
    const total_question = "<?php echo $total_question; ?>";
    const min_question = 20;
    let total_part = 1 + total_question % min_question; // 31
    let count = 1;
    let num_question = min_question;
    let check = total_question;

    // clear localStorage (timeout & current question)
    localStorage.clear();

    // tooltip
    $('[data-toggle="tooltip"]').tooltip();

    function setAttributes(el, attrs) {
        Object.keys(attrs).forEach(key => el.setAttribute(key, attrs[key]));
    }

    for (count = 1; count <= total_part; count++) {
        if (check < 30) {
            break;
        }
        check -= min_question;
    }
    total_part = count;
    
    for (let i = 1; i <= total_part; i++) {
        let exam_part = document.createElement('a');
        if (i == total_part) {
            num_question = total_question - (i-1)*min_question;
        }
        exam_part.innerHTML = "Part " + i + " (" + num_question + " câu)";
        setAttributes(exam_part, {
            class: 'btn btn-light w-100',
            href: 'take_exam.php?code=<?php echo $exam_code;?>&part=' + i
        })
        $('#exam-part-dropdown').append(exam_part);
    }

    let dataTable = $('#questions_table').DataTable({
        "processing": true,
        "serverSide": true,
        "order": [],
        "ajax": {
            url: "user_ajax_action.php",
            type: "POST",
            data: {
                action: 'fetch',
                page: 'view_exam',
                exam_id: exam_id
            }
        },
        "columnDefs": [{
                "targets": "_all",
                "orderable": false,
            },
            {
                "width": "25%",
                "targets": 1
            }
        ],
    });

});
</script>