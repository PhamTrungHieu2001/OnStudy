<?php

include('admin/Examination.php');

$exam = new Examination;

$exam->user_session_private();

include('header.php');

?>

<br />
<div class="card">
	<div class="card-header">
		<div class="row">
			<div class="col-md-9">
				<h3 class="panel-title">Exam attempts</h3>
			</div>
		</div>
	</div>
	<div class="card-body">
		<div class="table-responsive">
			<table id="attempt_table" class="display">
				<thead>
					<tr>
						<th>No.</th>
						<th>Part</th>
                        <th>Score</th>
                        <th>Date completed</th>
					</tr>
				</thead>
			</table>
		</div>
	</div>
</div>

<script>

$(document).ready(function(){
    const searchParams = new URLSearchParams(window.location.search);

    if (searchParams.has("id")) {
        let dataTable = $('#attempt_table').DataTable({
		"processing" : true,
		"serverSide" : true,
		"order" : [],
		"ajax" : {
			url:"user_ajax_action.php",
			type:"POST",
			data:{page:'attempt', id: searchParams.get("id")}
		},
		"columnDefs":[
			{
				"defaultContent": "-", 
				"targets": "_all", 
			},
			{
				"orderable": false,
				"targets": [0, 1],
			},
		],
	    });
    }
});

</script>

