<?php

include('admin/Examination.php');

$exam = new Examination;

$exam->user_session_private();

include('header.php');

?>

<br />
<div class="card">
	<div class="card-header">
		<div class="row">
			<div class="col-md-9">
				<h3 class="panel-title">Online exams</h3>
			</div>
		</div>
	</div>
	<div class="card-body">
		<div class="table-responsive">
			<table id="history_table" class="display">
				<thead>
					<tr>
						<th>No.</th>
						<th>Exam title</th>
                        <th>Total attempts</th>
                        <th>Last completed</th>
						<th>Action</th>
					</tr>
				</thead>
			</table>
		</div>
	</div>
</div>

<script>

$(document).ready(function(){
    const searchParams = new URLSearchParams(window.location.search);

    let dataTable = $('#history_table').DataTable({
        "processing" : true,
        "serverSide" : true,
        "order" : [],
        "ajax" : {
            url:"user_ajax_action.php",
            type:"POST",
            data:{action:'fetch', page:'history'}
        },
        "columnDefs":[
            {
                "defaultContent": "-", 
                "targets": "_all", 
            },
            {
                "orderable": false,
                "targets": [0, 1, 4],
            },
        ],
    });

});

</script>

