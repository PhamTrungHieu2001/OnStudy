<?php

//take_exam.php

require 'admin/Examination.php';

$exam = new Examination;

$exam->user_session_private();

require 'header.php';

$exam_id = '';
$exam_status = '';
$timeout = 0;
$remaining_minutes = '';
$start_time = '';
$end_time = '';
$part_duration = 20;
$part = $_GET['part'];

if (!isset($_GET['code']) || $_COOKIE['finish'] == 'true')
{
    header('location:index.php');
}

else if (isset($_GET['code'])) {
    $exam_id = $exam->Get_exam_id($_GET["code"]);
    $exam->query = " SELECT * FROM exams 
	WHERE exam_id = '$exam_id'
	";

    $result = $exam->query_result();

    foreach($result as $row)
    {
        $start_time = date('Y-m-d H:i:s', STRTOTIME(date('h:i:sa'))); // set current time to format "Y-m-d H:i:s"
        $duration = $part_duration . ' minute';
        $timeout = $part_duration * 60000;
        $end_time = STRTOTIME($start_time . '+' . $duration); // -> unix timestamp

        $end_time = date('Y-m-d H:i:s', $end_time);
        $remaining_minutes = strtotime($end_time) - time();
    }
    $part = $_GET['part'];
}

?>

<br />
<div class="container-fluid">
    <div class="row">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Online Exam</div>
                <div class="card-body">
                    <div id="single_question_area"></div>
                </div>
            </div>
            <br />
        </div>
        <div class="col-md-4 sticky">
            <div align="center">
                <div id="exam_timer" data-timer="">
                </div>
            </div>
            <div id="question_navigation_area"></div>
        </div>
    </div>
</div>

<script>
$(document).ready(function() {
    const exam_id = "<?php echo $exam_id; ?>";
    const timeout = "<?php echo $timeout; ?>";
    const part = "<?php echo $part; ?>";
    document.cookie = "exam_id = " + exam_id;
    document.cookie = "part = " + part;
    let remainingTime;
    // check if page is reloaded
    const pageAccessedByReload = (
        (window.performance.navigation && window.performance.navigation.type === 1) ||
        window.performance
        .getEntriesByType('navigation')
        .map((nav) => nav.type)
        .includes('reload')
    );

    // if page is reloaded -> load the current question
    if (pageAccessedByReload == true) {
        load_question(localStorage.getItem("current_question"));
    } else {
        load_question(); // show the current question
    }
    question_navigation(); // show question navigation

    if (!localStorage.getItem('startTime')) {
        localStorage.setItem('startTime', Date.now());
        remainingTime = timeout;
    } else {
        remainingTime = parseInt(localStorage.getItem('startTime')) + parseInt(timeout) - parseInt(Date.now());
        // if (remainingTime < 0) {
        //     remainingTime = 0;
        // }
    }

    $('#exam_timer').attr("data-timer", remainingTime / 1000);

    // Set timeout handler -> submit form
    setTimeout(function() {
            $('#user_answer_form').submit();
        },
        remainingTime);

    function load_question(question_id = '') {
        $.ajax({
            url: "user_ajax_action.php",
            method: "POST",
            data: {
                exam_id: exam_id,
                question_id: question_id,
                page: 'take_exam',
                action: 'load_question',
                part: part
            },
            success: function(data) {
                $('#single_question_area').html(data);
            }
        });
    }

    function question_navigation() {
        $.ajax({
            url: "user_ajax_action.php",
            method: "POST",
            data: {
                exam_id: exam_id,
                page: 'take_exam',
                action: 'question_navigation',
                part: part
            },
            success: function(data) {
                $('#question_navigation_area').html(data);
            }
        })
    }

    $(document).on('click', '.question_navigation', function() {
        let question_id = $(this).data('question_id');
        if (part == 'random') {
            load_question(question_id);
        }
        localStorage.setItem('current_question', question_id);
        $(".question_navigation").removeClass("glow");
        $("#" + question_id).addClass("glow");
        if ($('#question_' + question_id).length > 0) {
            $('#question_' + question_id)[0].scrollIntoView({behavior: 'smooth'});
        }
    });

    // Show timer
    $("#exam_timer").TimeCircles({
        time: {
            Days: {
                show: false
            },
            Hours: {
                show: false
            }
        }
    });

    // save selected options to local storage
    function updateCheckboxOption(checkboxElement) {
        const option_id = checkboxElement.attr('id');
        const question_id = checkboxElement.attr('data-question_id');
        let answer_option = [];
        // if question not exists -> create
        if (!localStorage.getItem(question_id)) {
            localStorage.setItem(question_id, "");
        }
        // if the option is checked and not exist -> add to local storage 
        if (checkboxElement.prop('checked')==true && (localStorage.getItem(question_id).indexOf(option_id) < 0)) {
            localStorage.setItem(question_id, localStorage.getItem(question_id) + ',' + option_id);
        }
        // if the option is unchecked and exists -> remove from local storage
        else if (checkboxElement.prop('checked')==false && localStorage.getItem(question_id).indexOf(option_id) >= 0) {
            // remove option from the local storage
            // if the first option -> remove option
            let remove = option_id;
            // if not the first option -> remove ',' + option
            if (!localStorage.getItem(question_id).startsWith(option_id)) {
                remove = ',' + option_id;
            }
            localStorage.setItem(question_id, localStorage.getItem(question_id).replace(remove, ''));
        }
        if (localStorage.getItem(question_id).startsWith(',')) {
            localStorage.setItem(question_id, localStorage.getItem(question_id).substring(1));
        }		
        if (localStorage.getItem(question_id) == '') {
            $('#' + question_id).removeClass('btn-primary');
        }
        // if a value in question is selected
        if (localStorage.getItem(question_id)) {
            let options = localStorage.getItem(question_id).split(',');
            for (let option of options) {
                let option_order = $('#' + option).data('id');
                answer_option.push(option_order);
                // console.log(option);
            }
        }
        // sort array & turn to string
        return answer_option.sort().join(","); 
    }

    // if user clicks on an option
    $(document).on('click', '.answer_option', function() {
        let question_id = $(this).data('question_id');
        let answer_option = $(this).data('id'); // option order
        let option_id = $(this).attr('id');
        $('#' + question_id).addClass('btn-primary');
        // check if question is multiple or one choice & check if the question exists & check if the option not exist
        if ($(this).is(':checkbox')) {
            answer_option = updateCheckboxOption($(this));
        } else {
            localStorage.setItem(question_id, option_id);
        }
        // console.log(answer_option);
        $.ajax({
            url: "user_ajax_action.php",
            method: "POST",
            data: {
                page: 'take_exam',
                action: 'answer',
                question_id: question_id,
                answer_option: answer_option,
                exam_id: exam_id,
                part: part
            },
            success: function(data) {}
        })
    });

    // submit answer form
    $('#user_answer_form').on('submit', function(event) {
        event.preventDefault();
        if (pageAccessedByReload == true) {
            return false;
        } 
        // set time = 0;
        // check the answer & move to result page: result.php
        // localStorage.clear();
        window.location.href = "result.php";
        // $.ajax({
        //     type: 'POST',
        //     url: $(this).attr('action'),
        //     dataType: 'json',
        //     success: function(json) {
        //         window.location.href = "result.php";
        //     }
        //  })
    });

});

</script>

</div>
</body>

</html>